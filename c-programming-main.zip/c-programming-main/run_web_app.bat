@echo off
title Apex Auto Wheels - Web Application Server
cd /d "%~dp0"
echo Starting Apex Auto Wheels Web Server...
start http://localhost:5173/
npm run dev
pause
