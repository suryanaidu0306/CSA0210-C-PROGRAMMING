#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILE_NAME "medicines.dat"

typedef struct {
    int id;
    char name[50];
    char category[50];
    char batch[20];
    char expiry[20];
    float price;
    int stock;
} Medicine;

// Function Prototypes
void login();
void dashboard();
void addMedicine();
void viewInventory();
void searchMedicine();
void editMedicine();
void deleteMedicine();
void posBilling();
void loadMedicines();
void saveMedicines();
int findMedicineById(int id);

Medicine inventory[1000];
int medCount = 0;

int main() {
    loadMedicines();
    printf("==========================================\n");
    printf("   MEDICAL STORE MANAGEMENT SYSTEM        \n");
    printf("==========================================\n");
    login();
    dashboard();
    return 0;
}

void login() {
    char username[20];
    char password[20];
    int attempts = 0;

    while (attempts < 3) {
        printf("\n--- Login ---\n");
        printf("Username: ");
        scanf("%19s", username);
        printf("Password: ");
        scanf("%19s", password);

        if (strcmp(username, "admin") == 0 && strcmp(password, "password") == 0) {
            printf("\nLogin successful! Welcome, %s.\n", username);
            return;
        } else {
            printf("Invalid credentials. Try again.\n");
            attempts++;
        }
    }
    printf("Too many failed attempts. Exiting.\n");
    exit(1);
}

void dashboard() {
    int choice;
    while (1) {
        printf("\n==========================================\n");
        printf("                DASHBOARD                 \n");
        printf("==========================================\n");
        printf("1. View Inventory\n");
        printf("2. Add Medicine\n");
        printf("3. Search Medicine\n");
        printf("4. Edit Medicine\n");
        printf("5. Delete Medicine\n");
        printf("6. POS (Billing)\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        if (scanf("%d", &choice) != 1) {
            while(getchar() != '\n'); // clear buffer
            printf("Invalid input. Please enter a number.\n");
            continue;
        }

        switch (choice) {
            case 1:
                viewInventory();
                break;
            case 2:
                addMedicine();
                break;
            case 3:
                searchMedicine();
                break;
            case 4:
                editMedicine();
                break;
            case 5:
                deleteMedicine();
                break;
            case 6:
                posBilling();
                break;
            case 7:
                saveMedicines();
                printf("Exiting... Data saved. Goodbye!\n");
                exit(0);
            default:
                printf("Invalid choice. Try again.\n");
        }
    }
}

void addMedicine() {
    if (medCount >= 1000) {
        printf("Inventory full!\n");
        return;
    }
    
    Medicine m;
    printf("\n--- Add New Medicine ---\n");
    
    printf("Enter ID (numeric): ");
    if (scanf("%d", &m.id) != 1) {
        while(getchar() != '\n');
        printf("Invalid input!\n");
        return;
    }
    
    if (findMedicineById(m.id) != -1) {
        printf("Medicine with this ID already exists!\n");
        return;
    }

    printf("Enter Name: ");
    scanf(" %[^\n]s", m.name); 
    
    printf("Enter Category: ");
    scanf(" %[^\n]s", m.category);
    
    printf("Enter Batch No: ");
    scanf("%19s", m.batch);
    
    printf("Enter Expiry Date (YYYY-MM-DD): ");
    scanf("%19s", m.expiry);
    
    printf("Enter Price: ");
    if (scanf("%f", &m.price) != 1) {
        while(getchar() != '\n');
        printf("Invalid price!\n");
        return;
    }
    
    printf("Enter Initial Stock: ");
    if (scanf("%d", &m.stock) != 1) {
        while(getchar() != '\n');
        printf("Invalid stock!\n");
        return;
    }
    
    inventory[medCount++] = m;
    saveMedicines();
    printf("Medicine added successfully!\n");
}

void viewInventory() {
    printf("\n--- Inventory ---\n");
    if (medCount == 0) {
        printf("Inventory is empty.\n");
        return;
    }
    
    printf("%-5s | %-20s | %-15s | %-10s | %-12s | %-8s | %-6s\n", 
           "ID", "Name", "Category", "Batch", "Expiry", "Price", "Stock");
    printf("----------------------------------------------------------------------------------------\n");
    
    for (int i = 0; i < medCount; i++) {
        printf("%-5d | %-20s | %-15s | %-10s | %-12s | $%-7.2f | ", 
               inventory[i].id, inventory[i].name, inventory[i].category, 
               inventory[i].batch, inventory[i].expiry, inventory[i].price);
        
        if (inventory[i].stock < 20) {
            printf("%-6d (LOW STOCK!)\n", inventory[i].stock);
        } else {
            printf("%-6d\n", inventory[i].stock);
        }
    }
}

void searchMedicine() {
    char query[50];
    int found = 0;
    printf("\n--- Search Medicine ---\n");
    printf("Enter Name or Category to search: ");
    scanf(" %[^\n]s", query);

    printf("\n%-5s | %-20s | %-15s | %-10s | %-12s | %-8s | %-6s\n", 
           "ID", "Name", "Category", "Batch", "Expiry", "Price", "Stock");
    printf("----------------------------------------------------------------------------------------\n");
    
    for (int i = 0; i < medCount; i++) {
        // Simple substring search (case sensitive for simplicity)
        if (strstr(inventory[i].name, query) != NULL || strstr(inventory[i].category, query) != NULL) {
            printf("%-5d | %-20s | %-15s | %-10s | %-12s | $%-7.2f | %-6d\n", 
                   inventory[i].id, inventory[i].name, inventory[i].category, 
                   inventory[i].batch, inventory[i].expiry, inventory[i].price, inventory[i].stock);
            found = 1;
        }
    }
    if (!found) {
        printf("No medicines matched your search.\n");
    }
}

void editMedicine() {
    int id, index;
    printf("\n--- Edit Medicine ---\n");
    printf("Enter ID of medicine to edit: ");
    if (scanf("%d", &id) != 1) {
        while(getchar() != '\n');
        printf("Invalid input!\n");
        return;
    }

    index = findMedicineById(id);
    if (index == -1) {
        printf("Medicine not found!\n");
        return;
    }

    printf("Current Name: %s\n", inventory[index].name);
    printf("Enter New Name (or same): ");
    scanf(" %[^\n]s", inventory[index].name);

    printf("Current Price: %.2f\n", inventory[index].price);
    printf("Enter New Price: ");
    if (scanf("%f", &inventory[index].price) != 1) {
        while(getchar() != '\n');
        printf("Invalid price!\n");
        return;
    }

    printf("Current Stock: %d\n", inventory[index].stock);
    printf("Enter New Stock: ");
    if (scanf("%d", &inventory[index].stock) != 1) {
        while(getchar() != '\n');
        printf("Invalid stock!\n");
        return;
    }

    saveMedicines();
    printf("Medicine updated successfully!\n");
}

void deleteMedicine() {
    int id, index;
    printf("\n--- Delete Medicine ---\n");
    printf("Enter ID of medicine to delete: ");
    if (scanf("%d", &id) != 1) {
        while(getchar() != '\n');
        printf("Invalid input!\n");
        return;
    }

    index = findMedicineById(id);
    if (index == -1) {
        printf("Medicine not found!\n");
        return;
    }

    for (int i = index; i < medCount - 1; i++) {
        inventory[i] = inventory[i + 1];
    }
    medCount--;
    saveMedicines();
    printf("Medicine deleted successfully!\n");
}

void posBilling() {
    int id, qty, index;
    float total = 0.0;
    char choice;
    
    printf("\n--- POS / Billing ---\n");
    if (medCount == 0) {
        printf("Inventory is empty. Cannot process billing.\n");
        return;
    }

    while (1) {
        printf("Enter Medicine ID to add to cart: ");
        if (scanf("%d", &id) != 1) {
            while(getchar() != '\n');
            printf("Invalid input!\n");
            continue;
        }
        
        index = findMedicineById(id);
        if (index == -1) {
            printf("Medicine not found!\n");
        } else {
            printf("Enter Quantity (Available: %d): ", inventory[index].stock);
            if (scanf("%d", &qty) != 1) {
                while(getchar() != '\n');
                printf("Invalid input!\n");
                continue;
            }
            
            if (qty > inventory[index].stock) {
                printf("Insufficient stock!\n");
            } else if (qty <= 0) {
                printf("Invalid quantity.\n");
            } else {
                inventory[index].stock -= qty;
                float cost = qty * inventory[index].price;
                total += cost;
                printf("Added %d x %s to cart. Cost: $%.2f\n", qty, inventory[index].name, cost);
            }
        }
        
        printf("Add another item? (y/n): ");
        scanf(" %c", &choice);
        if (choice == 'n' || choice == 'N') {
            break;
        }
    }
    
    saveMedicines();
    printf("\n--------------------------\n");
    printf("Total Amount Due: $%.2f\n", total);
    printf("Thank you for your purchase!\n");
    printf("--------------------------\n");
}

int findMedicineById(int id) {
    for (int i = 0; i < medCount; i++) {
        if (inventory[i].id == id) {
            return i;
        }
    }
    return -1;
}

void loadMedicines() {
    FILE *file = fopen(FILE_NAME, "rb");
    if (file == NULL) {
        medCount = 0;
        return;
    }
    medCount = fread(inventory, sizeof(Medicine), 1000, file);
    fclose(file);
}

void saveMedicines() {
    FILE *file = fopen(FILE_NAME, "wb");
    if (file == NULL) {
        printf("Error saving inventory data!\n");
        return;
    }
    fwrite(inventory, sizeof(Medicine), medCount, file);
    fclose(file);
}
