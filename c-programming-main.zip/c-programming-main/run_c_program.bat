@echo off
title Apex Auto Wheels - Native C Console Software
cd /d "%~dp0vehicle_rental_system"
if not exist vehicle_rental_centre.exe (
    echo Compiling vehicle_rental_centre.exe...
    gcc -std=c99 -Wall -Wextra -O2 main.c -o vehicle_rental_centre.exe
)
vehicle_rental_centre.exe
pause
