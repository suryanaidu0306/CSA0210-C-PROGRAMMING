import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Car,
  LayoutDashboard,
  CalendarCheck,
  Users,
  Wrench,
  Receipt,
  Terminal,
  LogOut,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { useStore } from '../store/StoreContext';

export const Sidebar: React.FC = () => {
  const { logout, currentUser } = useStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { to: '/', label: 'Executive Dashboard', icon: LayoutDashboard },
    { to: '/fleet', label: 'Fleet Inventory', icon: Car },
    { to: '/rentals', label: 'Rental Contracts & POS', icon: CalendarCheck },
    { to: '/customers', label: 'Customer CRM', icon: Users },
    { to: '/maintenance', label: 'Fleet Maintenance', icon: Wrench },
    { to: '/billing', label: 'Financials & Ledger', icon: Receipt },
    { to: '/terminal', label: 'C Engine & Terminal', icon: Terminal },
  ];

  return (
    <aside className="w-64 bg-slate-900/95 backdrop-blur-md border-r border-slate-800 flex flex-col h-full z-20 transition-all duration-300">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800/80 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/20 text-slate-950 font-black">
          <Car className="w-6 h-6" />
        </div>
        <div>
          <h1 className="font-extrabold text-white text-lg tracking-tight leading-tight flex items-center gap-1.5">
            APEX <span className="text-amber-400">WHEELS</span>
          </h1>
          <p className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400 inline" /> Vehicle Rental Centre
          </p>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1.5 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Main Management
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/10 text-amber-400 border border-amber-500/30 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`
              }
            >
              <Icon className="w-4 h-4" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* User Footer Card */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
        <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 flex items-center justify-between mb-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div className="truncate">
              <p className="text-xs font-semibold text-white truncate">{currentUser?.full_name || 'Admin User'}</p>
              <p className="text-[10px] font-medium text-amber-400">{currentUser?.role || 'ADMIN'}</p>
            </div>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Exit / Sign Out</span>
        </button>
      </div>
    </aside>
  );
};
