import React from 'react';
import { motion } from 'framer-motion';
import { type LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  color: 'blue' | 'purple' | 'green' | 'red';
  delay?: number;
}

export const MetricCard: React.FC<MetricCardProps> = ({ title, value, icon: Icon, color, delay = 0 }) => {
  const colorMap = {
    blue: 'text-neon-blue bg-neon-blue/10 border-neon-blue/20',
    purple: 'text-neon-purple bg-neon-purple/10 border-neon-purple/20',
    green: 'text-neon-green bg-neon-green/10 border-neon-green/20',
    red: 'text-neon-red bg-neon-red/10 border-neon-red/20',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: "easeOut" }}
      whileHover={{ scale: 1.02, translateY: -5 }}
      className="glass-card p-6 rounded-2xl flex items-center justify-between"
    >
      <div>
        <p className="text-slate-400 text-sm font-medium mb-1">{title}</p>
        <h3 className="text-3xl font-bold text-slate-100">{value}</h3>
      </div>
      <div className={`p-4 rounded-xl border ${colorMap[color]}`}>
        <Icon size={28} />
      </div>
    </motion.div>
  );
};
