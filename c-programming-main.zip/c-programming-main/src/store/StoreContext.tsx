import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export interface AddOnOptions {
  insurance_type: number; // 0: None, 1: Basic ($15/day), 2: Full Coverage ($30/day)
  gps: boolean;           // $8/day
  child_seat: boolean;    // $10/day
  extra_driver: boolean;  // $12/day
}

export interface Vehicle {
  id: number;
  plate: string;
  brand: string;
  model: string;
  year: number;
  category: 'Sedan' | 'SUV' | 'Luxury' | 'Minivan' | 'Motorcycle' | 'Commercial';
  transmission: 'Automatic' | 'Manual';
  fuel_type: 'Petrol' | 'Diesel' | 'Electric' | 'Hybrid';
  seats: number;
  daily_rate: number;
  hourly_rate: number;
  deposit_req: number;
  mileage: number;
  status: 'AVAILABLE' | 'RENTED' | 'MAINTENANCE' | 'RESERVED';
  is_deleted?: boolean;
}

export interface Customer {
  id: number;
  name: string;
  phone: string;
  email: string;
  id_passport: string;
  license_num: string;
  license_expiry: string;
  address: string;
  total_rentals: number;
  total_spent: number;
  is_deleted?: boolean;
}

export interface RentalBooking {
  booking_id: number;
  customer_id: number;
  customer_name: string;
  customer_phone: string;
  vehicle_id: number;
  vehicle_info: string;
  plate: string;
  start_date: string;
  expected_return_date: string;
  actual_return_date: string;
  duration_days: number;
  daily_rate: number;
  base_cost: number;
  addons: AddOnOptions;
  addons_cost: number;
  deposit_paid: number;
  start_mileage: number;
  return_mileage: number;
  excess_mileage_fee: number;
  late_fee: number;
  damage_fee: number;
  fuel_charge: number;
  total_cost: number;
  balance_settled: number;
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  notes: string;
}

export interface MaintenanceLog {
  log_id: number;
  vehicle_id: number;
  vehicle_info: string;
  date: string;
  service_type: string;
  cost: number;
  description: string;
  odometer_at_service: number;
  vendor_mechanic: string;
}

export interface Transaction {
  trans_id: number;
  date: string;
  type: 'RENTAL_DEPOSIT_ADVANCE' | 'FINAL_SETTLEMENT' | 'REFUND_ISSUED' | 'MAINTENANCE_EXPENSE';
  booking_id: number;
  vehicle_id: number;
  amount: number;
  description: string;
}

export interface UserAccount {
  username: string;
  full_name: string;
  role: 'ADMIN' | 'STAFF';
}

interface StoreContextType {
  vehicles: Vehicle[];
  customers: Customer[];
  rentals: RentalBooking[];
  maintenance: MaintenanceLog[];
  transactions: Transaction[];
  currentUser: UserAccount | null;
  isAuthenticated: boolean;
  login: (username: string, pass: string) => boolean;
  logout: () => void;
  addVehicle: (v: Omit<Vehicle, 'id'>) => void;
  updateVehicle: (id: number, v: Partial<Vehicle>) => void;
  deleteVehicle: (id: number) => boolean;
  addCustomer: (c: Omit<Customer, 'id' | 'total_rentals' | 'total_spent'>) => Customer;
  updateCustomer: (id: number, c: Partial<Customer>) => void;
  checkOutRental: (data: {
    customer_id: number;
    vehicle_id: number;
    start_date: string;
    expected_return_date: string;
    duration_days: number;
    addons: AddOnOptions;
    notes?: string;
  }) => RentalBooking;
  checkInRental: (data: {
    booking_id: number;
    actual_return_date: string;
    return_mileage: number;
    late_days: number;
    fuel_option: number; // 1: Full, 2: Missing ($45), 3: Empty ($90)
    damage_fee: number;
    damage_status: number; // 1: None, 2: Maintenance needed
  }) => RentalBooking | null;
  logMaintenance: (data: {
    vehicle_id: number;
    date: string;
    service_type: string;
    cost: number;
    description: string;
    odometer_at_service: number;
    vendor_mechanic: string;
    new_status: 'AVAILABLE' | 'MAINTENANCE';
  }) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const defaultVehicles: Vehicle[] = [
  { id: 101, plate: 'CAR-8821', brand: 'Toyota', model: 'Camry SE', year: 2023, category: 'Sedan', transmission: 'Automatic', fuel_type: 'Petrol', seats: 5, daily_rate: 55, hourly_rate: 10, deposit_req: 200, mileage: 18500, status: 'AVAILABLE' },
  { id: 102, plate: 'SUV-4930', brand: 'Ford', model: 'Explorer XLT', year: 2023, category: 'SUV', transmission: 'Automatic', fuel_type: 'Petrol', seats: 7, daily_rate: 85, hourly_rate: 15, deposit_req: 300, mileage: 24200, status: 'AVAILABLE' },
  { id: 103, plate: 'LUX-1102', brand: 'BMW', model: '530i M-Sport', year: 2024, category: 'Luxury', transmission: 'Automatic', fuel_type: 'Hybrid', seats: 5, daily_rate: 140, hourly_rate: 25, deposit_req: 500, mileage: 9400, status: 'AVAILABLE' },
  { id: 104, plate: 'EV-7741', brand: 'Tesla', model: 'Model 3 Long Range', year: 2023, category: 'Sedan', transmission: 'Automatic', fuel_type: 'Electric', seats: 5, daily_rate: 75, hourly_rate: 14, deposit_req: 300, mileage: 15300, status: 'AVAILABLE' },
  { id: 105, plate: 'SUV-9912', brand: 'Toyota', model: 'RAV4 Hybrid', year: 2022, category: 'SUV', transmission: 'Automatic', fuel_type: 'Hybrid', seats: 5, daily_rate: 65, hourly_rate: 12, deposit_req: 250, mileage: 31200, status: 'RENTED' },
  { id: 106, plate: 'VAN-3345', brand: 'Mercedes-Benz', model: 'Sprinter Passenger', year: 2022, category: 'Minivan', transmission: 'Automatic', fuel_type: 'Diesel', seats: 12, daily_rate: 130, hourly_rate: 22, deposit_req: 400, mileage: 42000, status: 'AVAILABLE' },
  { id: 107, plate: 'BIK-6619', brand: 'Yamaha', model: 'MT-07', year: 2023, category: 'Motorcycle', transmission: 'Manual', fuel_type: 'Petrol', seats: 2, daily_rate: 45, hourly_rate: 8, deposit_req: 150, mileage: 6800, status: 'AVAILABLE' },
  { id: 108, plate: 'TRK-5520', brand: 'Ford', model: 'F-150 SuperCrew', year: 2022, category: 'Commercial', transmission: 'Automatic', fuel_type: 'Diesel', seats: 5, daily_rate: 95, hourly_rate: 18, deposit_req: 350, mileage: 38600, status: 'AVAILABLE' },
  { id: 109, plate: 'CAR-2219', brand: 'Honda', model: 'Civic Touring', year: 2023, category: 'Sedan', transmission: 'Automatic', fuel_type: 'Petrol', seats: 5, daily_rate: 50, hourly_rate: 9, deposit_req: 200, mileage: 21000, status: 'AVAILABLE' },
  { id: 110, plate: 'LUX-7788', brand: 'Porsche', model: 'Macan GTS', year: 2024, category: 'Luxury', transmission: 'Automatic', fuel_type: 'Petrol', seats: 5, daily_rate: 180, hourly_rate: 30, deposit_req: 600, mileage: 5100, status: 'MAINTENANCE' },
];

const defaultCustomers: Customer[] = [
  { id: 201, name: 'Alexander Wright', phone: '+1-555-0143', email: 'a.wright@example.com', id_passport: 'US-P987123', license_num: 'DL-TX-99882', license_expiry: '2027-10-15', address: '742 Evergreen Terrace, Austin TX', total_rentals: 4, total_spent: 1350 },
  { id: 202, name: 'Sophia Martinez', phone: '+1-555-0188', email: 'sophia.m@example.com', id_passport: 'US-P443321', license_num: 'DL-CA-44551', license_expiry: '2028-04-20', address: '1204 Sunset Blvd, Los Angeles CA', total_rentals: 2, total_spent: 620 },
  { id: 203, name: 'David Chen', phone: '+1-555-0199', email: 'chen.d@example.com', id_passport: 'US-P665544', license_num: 'DL-NY-11223', license_expiry: '2026-11-30', address: '45 Wall St, New York NY', total_rentals: 1, total_spent: 385 },
];

const defaultRentals: RentalBooking[] = [
  {
    booking_id: 301,
    customer_id: 202,
    customer_name: 'Sophia Martinez',
    customer_phone: '+1-555-0188',
    vehicle_id: 105,
    vehicle_info: 'Toyota RAV4 Hybrid',
    plate: 'SUV-9912',
    start_date: '2026-09-01',
    expected_return_date: '2026-09-05',
    actual_return_date: '',
    duration_days: 4,
    daily_rate: 65,
    base_cost: 260,
    addons: { insurance_type: 1, gps: true, child_seat: false, extra_driver: false },
    addons_cost: 92,
    deposit_paid: 250,
    start_mileage: 31200,
    return_mileage: 0,
    excess_mileage_fee: 0,
    late_fee: 0,
    damage_fee: 0,
    fuel_charge: 0,
    total_cost: 352,
    balance_settled: 0,
    status: 'ACTIVE',
    notes: 'Customer requested early morning pickup.'
  },
  {
    booking_id: 300,
    customer_id: 201,
    customer_name: 'Alexander Wright',
    customer_phone: '+1-555-0143',
    vehicle_id: 103,
    vehicle_info: 'BMW 530i M-Sport',
    plate: 'LUX-1102',
    start_date: '2026-08-20',
    expected_return_date: '2026-08-23',
    actual_return_date: '2026-08-23',
    duration_days: 3,
    daily_rate: 140,
    base_cost: 420,
    addons: { insurance_type: 2, gps: true, child_seat: false, extra_driver: true },
    addons_cost: 150,
    deposit_paid: 500,
    start_mileage: 8700,
    return_mileage: 9400,
    excess_mileage_fee: 0,
    late_fee: 0,
    damage_fee: 0,
    fuel_charge: 0,
    total_cost: 570,
    balance_settled: 70,
    status: 'COMPLETED',
    notes: 'Executive business trip contract.'
  }
];

const defaultMaintenance: MaintenanceLog[] = [
  {
    log_id: 401,
    vehicle_id: 110,
    vehicle_info: 'Porsche Macan GTS [LUX-7788]',
    date: '2026-08-28',
    service_type: 'Brake Pad & Rotor Replacement',
    cost: 420,
    description: 'OEM performance brake pads installed at authorized service centre',
    odometer_at_service: 5100,
    vendor_mechanic: 'Porsche Centre North'
  },
  {
    log_id: 400,
    vehicle_id: 101,
    vehicle_info: 'Toyota Camry SE [CAR-8821]',
    date: '2026-08-15',
    service_type: 'Engine Oil & Filter Change',
    cost: 85,
    description: 'Full synthetic oil 0W-20 & OEM filter replacement',
    odometer_at_service: 15000,
    vendor_mechanic: 'Apex Auto Care Express'
  }
];

const defaultTransactions: Transaction[] = [
  { trans_id: 1001, date: '2026-09-01', type: 'RENTAL_DEPOSIT_ADVANCE', booking_id: 301, vehicle_id: 105, amount: 250, description: 'Deposit collected for Booking #301 (SUV-9912)' },
  { trans_id: 1000, date: '2026-08-23', type: 'FINAL_SETTLEMENT', booking_id: 300, vehicle_id: 103, amount: 70, description: 'Final settlement closed for Booking #300 (LUX-1102)' },
  { trans_id: 999, date: '2026-08-28', type: 'MAINTENANCE_EXPENSE', booking_id: 0, vehicle_id: 110, amount: -420, description: 'Brake System Service for Porsche Macan GTS (Log #401)' },
  { trans_id: 998, date: '2026-08-15', type: 'MAINTENANCE_EXPENSE', booking_id: 0, vehicle_id: 101, amount: -85, description: 'Oil & Filter Change for Toyota Camry (Log #400)' }
];

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(() => {
    const saved = localStorage.getItem('apex_vehicles');
    return saved ? JSON.parse(saved) : defaultVehicles;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('apex_customers');
    return saved ? JSON.parse(saved) : defaultCustomers;
  });

  const [rentals, setRentals] = useState<RentalBooking[]>(() => {
    const saved = localStorage.getItem('apex_rentals');
    return saved ? JSON.parse(saved) : defaultRentals;
  });

  const [maintenance, setMaintenance] = useState<MaintenanceLog[]>(() => {
    const saved = localStorage.getItem('apex_maintenance');
    return saved ? JSON.parse(saved) : defaultMaintenance;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('apex_transactions');
    return saved ? JSON.parse(saved) : defaultTransactions;
  });

  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('apex_user');
    return saved ? JSON.parse(saved) : { username: 'admin', full_name: 'Master Administrator', role: 'ADMIN' };
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('apex_auth') !== 'false';
  });

  useEffect(() => {
    localStorage.setItem('apex_vehicles', JSON.stringify(vehicles));
  }, [vehicles]);

  useEffect(() => {
    localStorage.setItem('apex_customers', JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem('apex_rentals', JSON.stringify(rentals));
  }, [rentals]);

  useEffect(() => {
    localStorage.setItem('apex_maintenance', JSON.stringify(maintenance));
  }, [maintenance]);

  useEffect(() => {
    localStorage.setItem('apex_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('apex_user', JSON.stringify(currentUser));
  }, [currentUser]);

  const login = (username: string, pass: string) => {
    if (username === 'admin' && pass === 'admin123') {
      const user: UserAccount = { username: 'admin', full_name: 'Master Administrator', role: 'ADMIN' };
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('apex_auth', 'true');
      return true;
    } else if (username === 'staff' && pass === 'staff123') {
      const user: UserAccount = { username: 'staff', full_name: 'Front Desk Officer', role: 'STAFF' };
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('apex_auth', 'true');
      return true;
    }
    // Also allow 'password' or default login for ease
    if (pass === 'password' || pass === 'admin123') {
      const user: UserAccount = { username: username || 'admin', full_name: 'Store Manager', role: 'ADMIN' };
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('apex_auth', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.setItem('apex_auth', 'false');
  };

  const addVehicle = (v: Omit<Vehicle, 'id'>) => {
    const maxId = vehicles.reduce((max, item) => item.id > max ? item.id : max, 100);
    const newV: Vehicle = { ...v, id: maxId + 1 };
    setVehicles(prev => [newV, ...prev]);
  };

  const updateVehicle = (id: number, updated: Partial<Vehicle>) => {
    setVehicles(prev => prev.map(item => item.id === id ? { ...item, ...updated } : item));
  };

  const deleteVehicle = (id: number) => {
    const target = vehicles.find(v => v.id === id);
    if (target?.status === 'RENTED') {
      return false;
    }
    setVehicles(prev => prev.filter(v => v.id !== id));
    return true;
  };

  const addCustomer = (c: Omit<Customer, 'id' | 'total_rentals' | 'total_spent'>) => {
    const maxId = customers.reduce((max, item) => item.id > max ? item.id : max, 200);
    const newC: Customer = { ...c, id: maxId + 1, total_rentals: 0, total_spent: 0 };
    setCustomers(prev => [newC, ...prev]);
    return newC;
  };

  const updateCustomer = (id: number, updated: Partial<Customer>) => {
    setCustomers(prev => prev.map(item => item.id === id ? { ...item, ...updated } : item));
  };

  const checkOutRental = (data: {
    customer_id: number;
    vehicle_id: number;
    start_date: string;
    expected_return_date: string;
    duration_days: number;
    addons: AddOnOptions;
    notes?: string;
  }) => {
    const cust = customers.find(c => c.id === data.customer_id);
    const veh = vehicles.find(v => v.id === data.vehicle_id);

    if (!cust || !veh) throw new Error('Customer or Vehicle not found');

    const maxBId = rentals.reduce((max, item) => item.booking_id > max ? item.booking_id : max, 300);
    const booking_id = maxBId + 1;

    const base_cost = veh.daily_rate * data.duration_days;
    let addRate = 0;
    if (data.addons.insurance_type === 1) addRate += 15;
    if (data.addons.insurance_type === 2) addRate += 30;
    if (data.addons.gps) addRate += 8;
    if (data.addons.child_seat) addRate += 10;
    if (data.addons.extra_driver) addRate += 12;

    const addons_cost = addRate * data.duration_days;
    const total_cost = base_cost + addons_cost;
    const deposit_paid = veh.deposit_req;

    const newBooking: RentalBooking = {
      booking_id,
      customer_id: cust.id,
      customer_name: cust.name,
      customer_phone: cust.phone,
      vehicle_id: veh.id,
      vehicle_info: `${veh.brand} ${veh.model}`,
      plate: veh.plate,
      start_date: data.start_date,
      expected_return_date: data.expected_return_date,
      actual_return_date: '',
      duration_days: data.duration_days,
      daily_rate: veh.daily_rate,
      base_cost,
      addons: data.addons,
      addons_cost,
      deposit_paid,
      start_mileage: veh.mileage,
      return_mileage: 0,
      excess_mileage_fee: 0,
      late_fee: 0,
      damage_fee: 0,
      fuel_charge: 0,
      total_cost,
      balance_settled: 0,
      status: 'ACTIVE',
      notes: data.notes || ''
    };

    // Update Vehicle
    updateVehicle(veh.id, { status: 'RENTED' });

    // Update Customer
    updateCustomer(cust.id, { total_rentals: cust.total_rentals + 1 });

    // Record Deposit Transaction
    const maxTId = transactions.reduce((max, item) => item.trans_id > max ? item.trans_id : max, 1000);
    const newTrans: Transaction = {
      trans_id: maxTId + 1,
      date: new Date().toISOString().split('T')[0],
      type: 'RENTAL_DEPOSIT_ADVANCE',
      booking_id,
      vehicle_id: veh.id,
      amount: deposit_paid,
      description: `Deposit collected for Booking #${booking_id} (${veh.plate})`
    };

    setRentals(prev => [newBooking, ...prev]);
    setTransactions(prev => [newTrans, ...prev]);

    return newBooking;
  };

  const checkInRental = (data: {
    booking_id: number;
    actual_return_date: string;
    return_mileage: number;
    late_days: number;
    fuel_option: number;
    damage_fee: number;
    damage_status: number;
  }) => {
    const booking = rentals.find(r => r.booking_id === data.booking_id);
    if (!booking) return null;

    const kmTravelled = data.return_mileage - booking.start_mileage;
    const allowedKm = booking.duration_days * 250;
    const excessKm = Math.max(0, kmTravelled - allowedKm);
    const excess_mileage_fee = excessKm * 0.35;
    const late_fee = data.late_days * 50;

    let fuel_charge = 0;
    if (data.fuel_option === 2) fuel_charge = 45;
    if (data.fuel_option === 3) fuel_charge = 90;

    const final_total = booking.base_cost + booking.addons_cost + excess_mileage_fee + late_fee + fuel_charge + data.damage_fee;
    const balance_settled = final_total - booking.deposit_paid;

    const updatedBooking: RentalBooking = {
      ...booking,
      actual_return_date: data.actual_return_date,
      return_mileage: data.return_mileage,
      excess_mileage_fee,
      late_fee,
      fuel_charge,
      damage_fee: data.damage_fee,
      total_cost: final_total,
      balance_settled,
      status: 'COMPLETED'
    };

    setRentals(prev => prev.map(r => r.booking_id === data.booking_id ? updatedBooking : r));

    // Update Vehicle
    updateVehicle(booking.vehicle_id, {
      mileage: data.return_mileage,
      status: data.damage_status === 2 ? 'MAINTENANCE' : 'AVAILABLE'
    });

    // Update Customer
    const cust = customers.find(c => c.id === booking.customer_id);
    if (cust) {
      updateCustomer(cust.id, { total_spent: cust.total_spent + final_total });
    }

    // Record Settlement Transaction
    const maxTId = transactions.reduce((max, item) => item.trans_id > max ? item.trans_id : max, 1000);
    const newTrans: Transaction = {
      trans_id: maxTId + 1,
      date: new Date().toISOString().split('T')[0],
      type: 'FINAL_SETTLEMENT',
      booking_id: booking.booking_id,
      vehicle_id: booking.vehicle_id,
      amount: balance_settled,
      description: `Final settlement for Booking #${booking.booking_id} (${booking.plate})`
    };

    setTransactions(prev => [newTrans, ...prev]);

    return updatedBooking;
  };

  const logMaintenance = (data: {
    vehicle_id: number;
    date: string;
    service_type: string;
    cost: number;
    description: string;
    odometer_at_service: number;
    vendor_mechanic: string;
    new_status: 'AVAILABLE' | 'MAINTENANCE';
  }) => {
    const veh = vehicles.find(v => v.id === data.vehicle_id);
    const maxMId = maintenance.reduce((max, item) => item.log_id > max ? item.log_id : max, 400);
    const log_id = maxMId + 1;

    const newLog: MaintenanceLog = {
      log_id,
      vehicle_id: data.vehicle_id,
      vehicle_info: veh ? `${veh.brand} ${veh.model} [${veh.plate}]` : `Vehicle #${data.vehicle_id}`,
      date: data.date,
      service_type: data.service_type,
      cost: data.cost,
      description: data.description,
      odometer_at_service: data.odometer_at_service,
      vendor_mechanic: data.vendor_mechanic
    };

    // Update vehicle
    updateVehicle(data.vehicle_id, {
      mileage: data.odometer_at_service,
      status: data.new_status
    });

    // Record Transaction
    const maxTId = transactions.reduce((max, item) => item.trans_id > max ? item.trans_id : max, 1000);
    const newTrans: Transaction = {
      trans_id: maxTId + 1,
      date: data.date,
      type: 'MAINTENANCE_EXPENSE',
      booking_id: 0,
      vehicle_id: data.vehicle_id,
      amount: -data.cost,
      description: `${data.service_type} for ${veh?.plate || 'Vehicle'} (Log #${log_id})`
    };

    setMaintenance(prev => [newLog, ...prev]);
    setTransactions(prev => [newTrans, ...prev]);
  };

  return (
    <StoreContext.Provider value={{
      vehicles, customers, rentals, maintenance, transactions, currentUser, isAuthenticated,
      login, logout, addVehicle, updateVehicle, deleteVehicle,
      addCustomer, updateCustomer, checkOutRental, checkInRental, logMaintenance
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
