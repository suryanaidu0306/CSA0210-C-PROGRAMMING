import React, { useState } from 'react';
import {
  CalendarCheck,
  KeyRound,
  CheckCircle,
  Clock,
  Printer,
  X,
  Car,
  AlertTriangle,
  Receipt
} from 'lucide-react';
import { useStore, type RentalBooking, type AddOnOptions } from '../store/StoreContext';

const Rentals: React.FC = () => {
  const { vehicles, customers, rentals, checkOutRental, checkInRental, addCustomer } = useStore();

  const [activeTab, setActiveTab] = useState<'ACTIVE' | 'HISTORY'>('ACTIVE');
  const [isCheckOutModalOpen, setIsCheckOutModalOpen] = useState(false);
  const [selectedReturnBooking, setSelectedReturnBooking] = useState<RentalBooking | null>(null);
  const [receiptBooking, setReceiptBooking] = useState<RentalBooking | null>(null);

  // Check-Out Form State
  const [selectedCustId, setSelectedCustId] = useState<number>(customers[0]?.id || 0);
  const [selectedVehId, setSelectedVehId] = useState<number>(0);
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [durationDays, setDurationDays] = useState<number>(3);
  const [expectedReturnDate, setExpectedReturnDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split('T')[0];
  });
  const [notes, setNotes] = useState('');
  const [addons, setAddons] = useState<AddOnOptions>({
    insurance_type: 1, // Basic CDW
    gps: true,
    child_seat: false,
    extra_driver: false
  });

  // Quick Customer Register in Modal
  const [isNewCustMode, setIsNewCustMode] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustLicense, setNewCustLicense] = useState('');

  // Check-In Return Form State
  const [actualReturnDate, setActualReturnDate] = useState(new Date().toISOString().split('T')[0]);
  const [returnMileage, setReturnMileage] = useState<number>(0);
  const [lateDays, setLateDays] = useState<number>(0);
  const [fuelOption, setFuelOption] = useState<number>(1); // 1: Full, 2: Missing, 3: Empty
  const [damageFee, setDamageFee] = useState<number>(0);
  const [damageStatus, setDamageStatus] = useState<number>(1); // 1: Available, 2: Maintenance

  const availableVehicles = vehicles.filter(v => !v.is_deleted && v.status === 'AVAILABLE');

  const handleOpenCheckOut = () => {
    if (availableVehicles.length > 0) {
      setSelectedVehId(availableVehicles[0].id);
    }
    setIsCheckOutModalOpen(true);
  };

  const handleOpenCheckIn = (booking: RentalBooking) => {
    setSelectedReturnBooking(booking);
    setActualReturnDate(new Date().toISOString().split('T')[0]);
    setReturnMileage(booking.start_mileage + (booking.duration_days * 180));
    setLateDays(0);
    setFuelOption(1);
    setDamageFee(0);
    setDamageStatus(1);
  };

  const handleCheckOutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let finalCustId = selectedCustId;

    if (isNewCustMode) {
      if (!newCustName || !newCustPhone || !newCustLicense) {
        alert('Please fill all quick customer registration fields.');
        return;
      }
      const created = addCustomer({
        name: newCustName,
        phone: newCustPhone,
        email: `${newCustName.toLowerCase().replace(/\s+/g, '.')}@example.com`,
        id_passport: 'US-AUTO',
        license_num: newCustLicense,
        license_expiry: '2028-12-31',
        address: 'Registered at Front Desk'
      });
      finalCustId = created.id;
    }

    if (!finalCustId || !selectedVehId) {
      alert('Please select a customer and an available vehicle.');
      return;
    }

    const booking = checkOutRental({
      customer_id: finalCustId,
      vehicle_id: selectedVehId,
      start_date: startDate,
      expected_return_date: expectedReturnDate,
      duration_days: durationDays,
      addons,
      notes
    });

    setIsCheckOutModalOpen(false);
    setReceiptBooking(booking);
  };

  const handleCheckInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReturnBooking) return;

    const closedBooking = checkInRental({
      booking_id: selectedReturnBooking.booking_id,
      actual_return_date: actualReturnDate,
      return_mileage: returnMileage,
      late_days: lateDays,
      fuel_option: fuelOption,
      damage_fee: damageFee,
      damage_status: damageStatus
    });

    setSelectedReturnBooking(null);
    if (closedBooking) {
      setReceiptBooking(closedBooking);
    }
  };

  const activeRentals = rentals.filter(r => r.status === 'ACTIVE');
  const completedRentals = rentals.filter(r => r.status !== 'ACTIVE');

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <CalendarCheck className="w-8 h-8 text-amber-400" /> Rental Operations & POS Contracts
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Check-out hire agreements, live on-road tracking, vehicle return inspection & instant settlement
          </p>
        </div>

        <button
          onClick={handleOpenCheckOut}
          disabled={availableVehicles.length === 0}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 disabled:opacity-50 transition-all shadow-lg shadow-orange-500/20"
        >
          <KeyRound className="w-4 h-4" /> New Vehicle Check-Out
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('ACTIVE')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-2 ${
            activeTab === 'ACTIVE'
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" /> Active On-Road ({activeRentals.length})
        </button>
        <button
          onClick={() => setActiveTab('HISTORY')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-2 ${
            activeTab === 'HISTORY'
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <CheckCircle className="w-4 h-4" /> Contract Archives ({completedRentals.length})
        </button>
      </div>

      {/* Table Section */}
      <div className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="text-[11px] uppercase tracking-wider text-slate-400 bg-slate-800/60 border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Contract ID</th>
                <th className="px-5 py-3.5">Customer Profile</th>
                <th className="px-5 py-3.5">Vehicle Details</th>
                <th className="px-5 py-3.5">Rental Window</th>
                <th className="px-5 py-3.5">Security Deposit</th>
                <th className="px-5 py-3.5">Total Amount</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {(activeTab === 'ACTIVE' ? activeRentals : completedRentals).map((rental) => (
                <tr key={rental.booking_id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="px-5 py-4 font-mono font-bold text-amber-400">#{rental.booking_id}</td>
                  <td className="px-5 py-4">
                    <div className="font-semibold text-white">{rental.customer_name}</div>
                    <div className="text-xs text-slate-400">{rental.customer_phone}</div>
                  </td>
                  <td className="px-5 py-4">
                    <div className="font-semibold text-slate-200">{rental.vehicle_info}</div>
                    <div className="font-mono text-xs text-amber-400">{rental.plate}</div>
                  </td>
                  <td className="px-5 py-4 text-xs text-slate-300">
                    <div>Start: {rental.start_date}</div>
                    <div className="text-amber-300 font-medium">
                      Return: {rental.actual_return_date || rental.expected_return_date} ({rental.duration_days} days)
                    </div>
                  </td>
                  <td className="px-5 py-4 font-mono font-medium text-slate-300">${rental.deposit_paid.toFixed(2)}</td>
                  <td className="px-5 py-4 font-mono font-bold text-emerald-400">${rental.total_cost.toFixed(2)}</td>
                  <td className="px-5 py-4">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        rental.status === 'ACTIVE'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      }`}
                    >
                      {rental.status}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-right space-x-2">
                    {rental.status === 'ACTIVE' ? (
                      <button
                        onClick={() => handleOpenCheckIn(rental)}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-sm"
                      >
                        Return Check-In
                      </button>
                    ) : (
                      <button
                        onClick={() => setReceiptBooking(rental)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 inline-flex items-center gap-1"
                      >
                        <Printer className="w-3.5 h-3.5" /> Invoice
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Check-Out Modal */}
      {isCheckOutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 md:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <KeyRound className="w-6 h-6 text-amber-400" /> New Vehicle Check-Out Agreement
              </h2>
              <button onClick={() => setIsCheckOutModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckOutSubmit} className="space-y-4">
              {/* Customer Selector */}
              <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Step 1: Select Customer</span>
                  <button
                    type="button"
                    onClick={() => setIsNewCustMode(!isNewCustMode)}
                    className="text-xs font-bold text-amber-400 hover:underline"
                  >
                    {isNewCustMode ? 'Choose Existing Client' : '+ Quick Register New Client'}
                  </button>
                </div>

                {!isNewCustMode ? (
                  <select
                    value={selectedCustId}
                    onChange={e => setSelectedCustId(parseInt(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                  >
                    {customers.filter(c => !c.is_deleted).map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone} • Lic: {c.license_num})
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={newCustName}
                      onChange={e => setNewCustName(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                    />
                    <input
                      type="text"
                      placeholder="Phone (+1-555...)"
                      value={newCustPhone}
                      onChange={e => setNewCustPhone(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                    />
                    <input
                      type="text"
                      placeholder="Driver License No"
                      value={newCustLicense}
                      onChange={e => setNewCustLicense(e.target.value)}
                      className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                    />
                  </div>
                )}
              </div>

              {/* Vehicle Selector */}
              <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Step 2: Select Available Vehicle</span>
                <select
                  value={selectedVehId}
                  onChange={e => setSelectedVehId(parseInt(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                >
                  {availableVehicles.map(v => (
                    <option key={v.id} value={v.id}>
                      {v.brand} {v.model} [{v.plate}] — ${v.daily_rate}/day (Deposit: ${v.deposit_req})
                    </option>
                  ))}
                </select>
              </div>

              {/* Rental Duration */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Pickup Date</label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Duration (Days)</label>
                  <input
                    type="number"
                    min="1"
                    max="90"
                    required
                    value={durationDays}
                    onChange={e => setDurationDays(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Expected Return</label>
                  <input
                    type="date"
                    required
                    value={expectedReturnDate}
                    onChange={e => setExpectedReturnDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>
              </div>

              {/* Add-ons & Insurance */}
              <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Protection & Add-On Packages</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="flex items-center gap-2 text-xs text-slate-200">
                    <input
                      type="radio"
                      name="insurance"
                      checked={addons.insurance_type === 1}
                      onChange={() => setAddons({ ...addons, insurance_type: 1 })}
                    />
                    Basic CDW Insurance (+$15/day)
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-200">
                    <input
                      type="radio"
                      name="insurance"
                      checked={addons.insurance_type === 2}
                      onChange={() => setAddons({ ...addons, insurance_type: 2 })}
                    />
                    Full Comprehensive (+$30/day)
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-200">
                    <input
                      type="checkbox"
                      checked={addons.gps}
                      onChange={e => setAddons({ ...addons, gps: e.target.checked })}
                    />
                    GPS Satellite Navigation (+$8/day)
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-200">
                    <input
                      type="checkbox"
                      checked={addons.child_seat}
                      onChange={e => setAddons({ ...addons, child_seat: e.target.checked })}
                    />
                    Child Safety Seat (+$10/day)
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCheckOutModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20"
                >
                  Confirm Check-Out & Collect Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Check-In / Return Settlement Modal */}
      {selectedReturnBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 md:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <CheckCircle className="w-6 h-6 text-emerald-400" /> Return Inspection & Final Settlement
              </h2>
              <button onClick={() => setSelectedReturnBooking(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckInSubmit} className="space-y-4">
              <div className="bg-slate-800/40 p-4 rounded-2xl border border-slate-800 space-y-1 text-xs">
                <p className="font-semibold text-white">Booking #{selectedReturnBooking.booking_id} — {selectedReturnBooking.customer_name}</p>
                <p className="text-slate-400">Vehicle: {selectedReturnBooking.vehicle_info} [{selectedReturnBooking.plate}]</p>
                <p className="text-slate-400">Pickup Odometer: {selectedReturnBooking.start_mileage.toLocaleString()} KM | Advance Deposit: ${selectedReturnBooking.deposit_paid}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Return Odometer Reading (KM)</label>
                  <input
                    type="number"
                    min={selectedReturnBooking.start_mileage}
                    required
                    value={returnMileage}
                    onChange={e => setReturnMileage(parseFloat(e.target.value) || 0)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                  <span className="text-[11px] text-slate-400">Allowance: {selectedReturnBooking.duration_days * 250} KM</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Overdue / Late Days</label>
                  <input
                    type="number"
                    min="0"
                    value={lateDays}
                    onChange={e => setLateDays(parseInt(e.target.value) || 0)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                  <span className="text-[11px] text-slate-400">Penalty: $50.00 / day</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Fuel Tank Status</label>
                  <select
                    value={fuelOption}
                    onChange={e => setFuelOption(parseInt(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  >
                    <option value={1}>Full Tank (No surcharge)</option>
                    <option value={2}>Missing Fuel (Apply $45.00 refuel)</option>
                    <option value={3}>Empty (Apply $90.00 refuel)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Damage Assessment Deduction ($)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={damageFee}
                    onChange={e => setDamageFee(parseFloat(e.target.value) || 0)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Vehicle Release Destination</label>
                <select
                  value={damageStatus}
                  onChange={e => setDamageStatus(parseInt(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                >
                  <option value={1}>Mark as AVAILABLE (Ready for next hire)</option>
                  <option value={2}>Send to MAINTENANCE (Repairs needed)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedReturnBooking(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20"
                >
                  Finalize Return & Settlement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* POS Receipt / Invoice Modal */}
      {receiptBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 md:p-8 shadow-2xl space-y-6 my-8 font-sans">
            <div className="text-center border-b border-slate-800 pb-4">
              <h3 className="text-lg font-black text-white tracking-wider uppercase">Apex Auto Wheels</h3>
              <p className="text-xs text-slate-400">Official Vehicle Rental Agreement & Settlement</p>
              <span className="inline-block mt-2 px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Contract #{receiptBooking.booking_id}
              </span>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Customer:</span>
                <span className="font-semibold text-white">{receiptBooking.customer_name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Vehicle:</span>
                <span className="font-semibold text-white">{receiptBooking.vehicle_info} ({receiptBooking.plate})</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Duration:</span>
                <span>{receiptBooking.duration_days} Days ({receiptBooking.start_date} to {receiptBooking.actual_return_date || receiptBooking.expected_return_date})</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Base Hire Charge:</span>
                <span>${receiptBooking.base_cost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Protection & Add-ons:</span>
                <span>${receiptBooking.addons_cost.toFixed(2)}</span>
              </div>

              {receiptBooking.excess_mileage_fee > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-800/60 text-amber-400">
                  <span>Excess Mileage Fee:</span>
                  <span>+${receiptBooking.excess_mileage_fee.toFixed(2)}</span>
                </div>
              )}

              {receiptBooking.late_fee > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-800/60 text-rose-400">
                  <span>Late Return Penalty:</span>
                  <span>+${receiptBooking.late_fee.toFixed(2)}</span>
                </div>
              )}

              {receiptBooking.damage_fee > 0 && (
                <div className="flex justify-between py-1 border-b border-slate-800/60 text-rose-400">
                  <span>Vehicle Damage Fee:</span>
                  <span>+${receiptBooking.damage_fee.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between py-2 text-sm font-bold text-white border-t border-slate-700">
                <span>Total Charges:</span>
                <span className="text-amber-400 font-mono">${receiptBooking.total_cost.toFixed(2)}</span>
              </div>

              <div className="flex justify-between py-1 text-slate-300">
                <span>Deposit Paid:</span>
                <span>${receiptBooking.deposit_paid.toFixed(2)}</span>
              </div>

              <div className="flex justify-between py-2 text-sm font-bold rounded-xl bg-slate-800 p-3">
                <span>Net Settlement:</span>
                <span className="font-mono text-emerald-400">
                  {receiptBooking.balance_settled >= 0
                    ? `Due: $${receiptBooking.balance_settled.toFixed(2)} (Paid)`
                    : `Refunded: $${Math.abs(receiptBooking.balance_settled).toFixed(2)}`}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" /> Print POS Receipt
              </button>
              <button
                onClick={() => setReceiptBooking(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rentals;
