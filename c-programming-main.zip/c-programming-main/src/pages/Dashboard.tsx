import React from 'react';
import { Link } from 'react-router-dom';
import {
  Car,
  TrendingUp,
  DollarSign,
  CalendarCheck,
  Wrench,
  KeyRound,
  ArrowUpRight,
  ShieldAlert,
  Fuel,
  Activity,
  Plus
} from 'lucide-react';
import { useStore } from '../store/StoreContext';

const Dashboard: React.FC = () => {
  const { vehicles, rentals, maintenance, transactions, customers } = useStore();

  const activeVehicles = vehicles.filter(v => !v.is_deleted);
  const availableVehicles = activeVehicles.filter(v => v.status === 'AVAILABLE');
  const rentedVehicles = activeVehicles.filter(v => v.status === 'RENTED');
  const maintenanceVehicles = activeVehicles.filter(v => v.status === 'MAINTENANCE');

  const utilizationRate = activeVehicles.length > 0
    ? Math.round((rentedVehicles.length / activeVehicles.length) * 100)
    : 0;

  const grossRevenue = rentals
    .filter(r => r.status === 'COMPLETED')
    .reduce((sum, r) => sum + r.total_cost, 0);

  const maintenanceCost = maintenance.reduce((sum, m) => sum + m.cost, 0);
  const netProfit = grossRevenue - maintenanceCost;

  const activeDeposits = rentals
    .filter(r => r.status === 'ACTIVE')
    .reduce((sum, r) => sum + r.deposit_paid, 0);

  const activeRentalsList = rentals.filter(r => r.status === 'ACTIVE');

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950/40 p-6 md:p-8 border border-slate-700/60 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 mb-3">
              <Activity className="w-3.5 h-3.5" /> Operations Live Status
            </span>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
              Apex Vehicle Rental <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">Control Hub</span>
            </h1>
            <p className="text-sm text-slate-400 mt-1 max-w-xl">
              All-in-one management for your vehicle rental business: fleet inventory, customer CRM, active bookings, check-in/check-out contracts, and financial intelligence.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Link
              to="/rentals"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 transition-all shadow-lg shadow-orange-500/25"
            >
              <KeyRound className="w-4 h-4" />
              New Rental Check-Out
            </Link>
            <Link
              to="/fleet"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Fleet Vehicle
            </Link>
          </div>
        </div>

        {/* Ambient background glow */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Top Level Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Fleet Size</span>
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Car className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-extrabold text-white">{activeVehicles.length}</div>
            <div className="flex items-center gap-2 mt-2 text-xs font-medium">
              <span className="text-emerald-400">{availableVehicles.length} ready</span>
              <span className="text-slate-600">•</span>
              <span className="text-amber-400">{rentedVehicles.length} on-road</span>
              <span className="text-slate-600">•</span>
              <span className="text-rose-400">{maintenanceVehicles.length} service</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Fleet Utilization</span>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-extrabold text-amber-400">{utilizationRate}%</div>
            <div className="w-full bg-slate-800 rounded-full h-2 mt-3 overflow-hidden">
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-500" style={{ width: `${utilizationRate}%` }} />
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Gross Rental Revenue</span>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-extrabold text-emerald-400">${grossRevenue.toFixed(2)}</div>
            <p className="text-xs text-slate-400 mt-2">
              Deposits in hand: <span className="text-amber-300 font-semibold">${activeDeposits.toFixed(2)}</span>
            </p>
          </div>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Net Operating Profit</span>
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className={`text-3xl font-extrabold ${netProfit >= 0 ? 'text-purple-400' : 'text-red-400'}`}>
              ${netProfit.toFixed(2)}
            </div>
            <p className="text-xs text-slate-400 mt-2">
              Maint expense: <span className="text-rose-400 font-semibold">${maintenanceCost.toFixed(2)}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Main Content Split: Active Rentals & Fleet Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Active Rentals */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <CalendarCheck className="w-5 h-5 text-amber-400" /> Currently Active Hires (On-Road)
              </h2>
              <p className="text-xs text-slate-400">Live contracts awaiting return and check-in settlement</p>
            </div>
            <Link to="/rentals" className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1">
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
            {activeRentalsList.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <Car className="w-12 h-12 mx-auto text-slate-600 mb-3" />
                <p className="font-semibold text-white">No active hires right now</p>
                <p className="text-xs text-slate-400 mt-1">All fleet vehicles are parked and available for rent.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-300">
                  <thead className="text-[11px] uppercase tracking-wider text-slate-400 bg-slate-800/60 border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-3">Booking</th>
                      <th className="px-4 py-3">Customer</th>
                      <th className="px-4 py-3">Vehicle</th>
                      <th className="px-4 py-3">Pickup</th>
                      <th className="px-4 py-3">Return Due</th>
                      <th className="px-4 py-3">Deposit</th>
                      <th className="px-4 py-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {activeRentalsList.map((rental) => (
                      <tr key={rental.booking_id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-4 py-3 font-mono font-bold text-amber-400">#{rental.booking_id}</td>
                        <td className="px-4 py-3 font-medium text-white">{rental.customer_name}</td>
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-200">{rental.vehicle_info}</span>
                          <span className="block text-[11px] font-mono text-slate-400">{rental.plate}</span>
                        </td>
                        <td className="px-4 py-3 text-xs text-slate-400">{rental.start_date}</td>
                        <td className="px-4 py-3 text-xs text-amber-300 font-semibold">{rental.expected_return_date}</td>
                        <td className="px-4 py-3 font-mono font-medium text-emerald-400">${rental.deposit_paid}</td>
                        <td className="px-4 py-3 text-right">
                          <Link
                            to="/rentals"
                            className="inline-flex items-center px-3 py-1 rounded-lg text-xs font-bold bg-amber-500/10 text-amber-400 hover:bg-amber-500 hover:text-slate-950 transition-colors"
                          >
                            Return Check-In
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Quick Shortcuts Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <Link to="/fleet" className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-center group transition-all">
              <Car className="w-6 h-6 mx-auto text-amber-400 group-hover:scale-110 transition-transform mb-2" />
              <div className="text-xs font-bold text-white">Fleet Manager</div>
              <div className="text-[11px] text-slate-400">{activeVehicles.length} vehicles</div>
            </Link>

            <Link to="/customers" className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-center group transition-all">
              <KeyRound className="w-6 h-6 mx-auto text-blue-400 group-hover:scale-110 transition-transform mb-2" />
              <div className="text-xs font-bold text-white">Client CRM</div>
              <div className="text-[11px] text-slate-400">{customers.length} clients</div>
            </Link>

            <Link to="/maintenance" className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-center group transition-all">
              <Wrench className="w-6 h-6 mx-auto text-rose-400 group-hover:scale-110 transition-transform mb-2" />
              <div className="text-xs font-bold text-white">Service Logs</div>
              <div className="text-[11px] text-slate-400">{maintenance.length} events</div>
            </Link>

            <Link to="/terminal" className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-center group transition-all">
              <ShieldAlert className="w-6 h-6 mx-auto text-emerald-400 group-hover:scale-110 transition-transform mb-2" />
              <div className="text-xs font-bold text-white">C Engine View</div>
              <div className="text-[11px] text-slate-400">Terminal mode</div>
            </Link>
          </div>
        </div>

        {/* Right 1 Col: Fleet Status & Health Alerts */}
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" /> Fleet Health & Alerts
            </h2>
            <p className="text-xs text-slate-400">Service milestones (every 10,000 KM)</p>
          </div>

          <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-4 border border-slate-800 space-y-3">
            {activeVehicles.slice(0, 4).map((veh) => {
              const km = veh.mileage;
              const due = (km % 10000) > 8500;
              const isMaint = veh.status === 'MAINTENANCE';

              return (
                <div key={veh.id} className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white truncate">{veh.brand} {veh.model}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">{veh.plate}</span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                      <span>{veh.mileage.toLocaleString()} KM</span>
                      <span>•</span>
                      <span className="flex items-center gap-1"><Fuel className="w-3 h-3 text-amber-400" /> {veh.fuel_type}</span>
                    </div>
                  </div>

                  <div>
                    {isMaint ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                        In Repair
                      </span>
                    ) : due ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        Service Due
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Good
                      </span>
                    )}
                  </div>
                </div>
              );
            })}

            <Link
              to="/maintenance"
              className="w-full mt-2 py-2 px-3 rounded-xl text-xs font-semibold text-center text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 block transition-colors"
            >
              Open Maintenance Tracker
            </Link>
          </div>

          {/* Recent Financial Ledger Snapshot */}
          <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-4 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Recent Cash Inflows & Outflows</h3>
            <div className="space-y-2">
              {transactions.slice(0, 3).map((t) => (
                <div key={t.trans_id} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-800/30">
                  <div className="truncate mr-2">
                    <p className="font-semibold text-slate-200 truncate">{t.description}</p>
                    <p className="text-[10px] text-slate-400">{t.date}</p>
                  </div>
                  <span className={`font-mono font-bold ${t.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {t.amount >= 0 ? `+$${t.amount.toFixed(2)}` : `-$${Math.abs(t.amount).toFixed(2)}`}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
