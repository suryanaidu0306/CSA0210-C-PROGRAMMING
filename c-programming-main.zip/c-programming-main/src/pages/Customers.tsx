import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Edit2,
  X,
  CreditCard,
  KeyRound,
  History
} from 'lucide-react';
import { useStore, type Customer } from '../store/StoreContext';

const Customers: React.FC = () => {
  const { customers, rentals, addCustomer, updateCustomer } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCust, setEditingCust] = useState<Customer | null>(null);
  const [historyCust, setHistoryCust] = useState<Customer | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    id_passport: '',
    license_num: '',
    license_expiry: '2028-12-31',
    address: ''
  });

  const filteredCustomers = customers.filter(c => {
    if (c.is_deleted) return false;
    const term = searchTerm.toLowerCase();
    return (
      c.name.toLowerCase().includes(term) ||
      c.phone.toLowerCase().includes(term) ||
      c.license_num.toLowerCase().includes(term) ||
      c.email.toLowerCase().includes(term)
    );
  });

  const handleOpenAdd = () => {
    setEditingCust(null);
    setFormData({
      name: '',
      phone: '',
      email: '',
      id_passport: '',
      license_num: '',
      license_expiry: '2028-12-31',
      address: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Customer) => {
    setEditingCust(c);
    setFormData({
      name: c.name,
      phone: c.phone,
      email: c.email,
      id_passport: c.id_passport,
      license_num: c.license_num,
      license_expiry: c.license_expiry,
      address: c.address
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCust) {
      updateCustomer(editingCust.id, formData);
    } else {
      addCustomer(formData);
    }
    setIsModalOpen(false);
  };

  const customerRentals = historyCust
    ? rentals.filter(r => r.customer_id === historyCust.id)
    : [];

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Users className="w-8 h-8 text-amber-400" /> Customer Relationship Management (CRM)
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Registered client directory, driver's license records, and lifetime value analytics
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 transition-all shadow-lg shadow-orange-500/20"
        >
          <Plus className="w-4 h-4" /> Register New Customer
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-4 border border-slate-800">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search by customer name, phone number, or driver's license number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Customer Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredCustomers.map((cust) => (
          <div
            key={cust.id}
            className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 p-5 flex flex-col justify-between hover:border-slate-700 transition-all shadow-sm"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400">
                  {cust.name.charAt(0)}
                </div>
                <span className="text-xs font-mono font-bold text-slate-400">ID #{cust.id}</span>
              </div>

              <h3 className="text-lg font-bold text-white mb-1">{cust.name}</h3>
              <p className="text-xs text-slate-400 mb-3">{cust.phone} • {cust.email}</p>

              <div className="bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs text-slate-300 mb-4">
                <div className="flex justify-between">
                  <span className="text-slate-400">Driver License:</span>
                  <span className="font-mono font-semibold text-white">{cust.license_num}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">License Expiry:</span>
                  <span className="text-amber-300">{cust.license_expiry}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Passport / ID:</span>
                  <span>{cust.id_passport}</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between pt-3 border-t border-slate-800 mb-3 text-xs">
                <div>
                  <span className="text-slate-400">Total Hires: </span>
                  <span className="font-bold text-white">{cust.total_rentals}</span>
                </div>
                <div>
                  <span className="text-slate-400">Lifetime Spent: </span>
                  <span className="font-bold text-emerald-400">${cust.total_spent.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setHistoryCust(cust)}
                  className="flex-1 py-2 rounded-xl text-xs font-bold bg-amber-500/10 text-amber-400 hover:bg-amber-500 hover:text-slate-950 border border-amber-500/20 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <History className="w-3.5 h-3.5" /> Rental History
                </button>
                <button
                  onClick={() => handleOpenEdit(cust)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 border border-slate-700 transition-colors"
                  title="Edit client"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 md:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Users className="w-6 h-6 text-amber-400" />
                {editingCust ? 'Edit Customer Profile' : 'Register New Client'}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Full Legal Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  placeholder="e.g. Alexander Wright"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Phone Number</label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                    placeholder="+1-555-0143"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                    placeholder="client@example.com"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Driver's License No.</label>
                  <input
                    type="text"
                    required
                    value={formData.license_num}
                    onChange={e => setFormData({ ...formData, license_num: e.target.value.toUpperCase() })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm"
                    placeholder="DL-TX-99882"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">License Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={formData.license_expiry}
                    onChange={e => setFormData({ ...formData, license_expiry: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Passport / National ID</label>
                <input
                  type="text"
                  required
                  value={formData.id_passport}
                  onChange={e => setFormData({ ...formData, id_passport: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  placeholder="US-P987123"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Residential Address</label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  placeholder="742 Evergreen Terrace, Austin TX"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20"
                >
                  {editingCust ? 'Save Profile Updates' : 'Register Client'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Rental History Modal */}
      {historyCust && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 md:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-bold text-white">Rental History: {historyCust.name}</h2>
                <p className="text-xs text-slate-400">License: {historyCust.license_num} • Phone: {historyCust.phone}</p>
              </div>
              <button onClick={() => setHistoryCust(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {customerRentals.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <p className="font-semibold text-white">No rental records on file for this customer.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {customerRentals.map(r => (
                  <div key={r.booking_id} className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-amber-400">#{r.booking_id}</span>
                        <span className="font-bold text-white text-sm">{r.vehicle_info}</span>
                        <span className="font-mono text-xs text-slate-400">[{r.plate}]</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        {r.start_date} to {r.actual_return_date || r.expected_return_date} ({r.duration_days} days)
                      </p>
                    </div>

                    <div className="text-right">
                      <div className="font-mono font-bold text-emerald-400">${r.total_cost.toFixed(2)}</div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-slate-800 text-slate-300">
                        {r.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-end pt-4 border-t border-slate-800">
              <button
                onClick={() => setHistoryCust(null)}
                className="px-5 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;
