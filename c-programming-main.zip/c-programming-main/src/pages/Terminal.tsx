import React, { useState } from 'react';
import {
  Terminal as TerminalIcon,
  Code,
  Download,
  Copy,
  Check,
  Play,
  Cpu,
  RefreshCw
} from 'lucide-react';
import { useStore } from '../store/StoreContext';

const Terminal: React.FC = () => {
  const { vehicles, rentals, customers, maintenance } = useStore();
  const [copied, setCopied] = useState(false);
  const [commandInput, setCommandInput] = useState('');
  const [terminalHistory, setTerminalHistory] = useState<string[]>([
    '*** APEX AUTO WHEELS - VEHICLE RENTAL CENTRE C ENGINE SIMULATOR ***',
    'Compiled with GCC (MinGW-w64 16.1.0) / C99 Standard',
    'Type "help" for a list of available command operations.',
    ''
  ]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = commandInput.trim().toLowerCase();
    if (!cmd) return;

    let response: string[] = [`> ${commandInput}`];

    switch (cmd) {
      case 'help':
        response.push(
          'Available C CLI Commands:',
          '  status        - Print live fleet status & utilization summary',
          '  vehicles      - List all registered vehicles in inventory',
          '  available     - List vehicles currently ready for hire',
          '  rentals       - Display active on-road rental contracts',
          '  customers     - List client CRM profiles',
          '  maintenance   - View fleet maintenance logs',
          '  clear         - Clear the terminal screen',
          '  compile       - Check GCC compilation instructions'
        );
        break;

      case 'status': {
        const available = vehicles.filter(v => v.status === 'AVAILABLE').length;
        const rented = vehicles.filter(v => v.status === 'RENTED').length;
        const maint = vehicles.filter(v => v.status === 'MAINTENANCE').length;
        response.push(
          '=================================================================',
          '   APEX AUTO WHEELS - FLEET OPERATIONAL STATUS                   ',
          '=================================================================',
          `Total Fleet Size : ${vehicles.length} vehicles`,
          `Available Ready  : ${available} vehicles`,
          `Rented (On-Road) : ${rented} vehicles`,
          `Under Repair     : ${maint} vehicles`,
          `Fleet Utilization: ${vehicles.length > 0 ? Math.round((rented / vehicles.length) * 100) : 0}%`,
          '================================================================='
        );
        break;
      }

      case 'vehicles':
        response.push(
          'ID    | Plate No   | Make & Model           | Category   | Rate/Day  | Status',
          '-----------------------------------------------------------------------------'
        );
        vehicles.forEach(v => {
          response.push(
            `#${v.id.toString().padEnd(4)} | ${v.plate.padEnd(10)} | ${(v.brand + ' ' + v.model).padEnd(22)} | ${v.category.padEnd(10)} | $${v.daily_rate.toFixed(2).padEnd(8)} | ${v.status}`
          );
        });
        break;

      case 'available':
        response.push(
          'AVAILABLE VEHICLES READY FOR HIRE:',
          'ID    | Plate No   | Make & Model           | Daily Rate | Deposit',
          '-------------------------------------------------------------------'
        );
        vehicles.filter(v => v.status === 'AVAILABLE').forEach(v => {
          response.push(
            `#${v.id.toString().padEnd(4)} | ${v.plate.padEnd(10)} | ${(v.brand + ' ' + v.model).padEnd(22)} | $${v.daily_rate.toFixed(2).padEnd(9)} | $${v.deposit_req.toFixed(2)}`
          );
        });
        break;

      case 'rentals':
        response.push(
          'ACTIVE ON-ROAD CONTRACTS:',
          'Book ID | Customer             | Vehicle               | Plate      | Due Date',
          '-------------------------------------------------------------------------------'
        );
        rentals.filter(r => r.status === 'ACTIVE').forEach(r => {
          response.push(
            `#${r.booking_id.toString().padEnd(6)} | ${r.customer_name.padEnd(20)} | ${r.vehicle_info.padEnd(21)} | ${r.plate.padEnd(10)} | ${r.expected_return_date}`
          );
        });
        break;

      case 'customers':
        response.push(
          'ID    | Customer Name        | Phone           | License No     | Total Rentals',
          '-------------------------------------------------------------------------------'
        );
        customers.forEach(c => {
          response.push(
            `#${c.id.toString().padEnd(4)} | ${c.name.padEnd(20)} | ${c.phone.padEnd(15)} | ${c.license_num.padEnd(14)} | ${c.total_rentals}`
          );
        });
        break;

      case 'maintenance':
        response.push(
          'FLEET SERVICE ARCHIVES:',
          'Log ID | Vehicle Info                   | Service Type             | Cost',
          '--------------------------------------------------------------------------'
        );
        maintenance.forEach(m => {
          response.push(
            `#${m.log_id.toString().padEnd(5)} | ${m.vehicle_info.padEnd(30)} | ${m.service_type.padEnd(24)} | $${m.cost.toFixed(2)}`
          );
        });
        break;

      case 'clear':
        setTerminalHistory([]);
        setCommandInput('');
        return;

      case 'compile':
        response.push(
          'How to run native C program:',
          '  1. Open PowerShell / Command Prompt in:',
          '     c:\\Users\\SAMEER\\web application\\vehicle_rental_system',
          '  2. Run command:',
          '     gcc -std=c99 -Wall -Wextra -O2 main.c -o vehicle_rental_centre.exe',
          '     .\\vehicle_rental_centre.exe',
          '  (Or double-click build.bat)'
        );
        break;

      default:
        response.push(`Unknown command: "${cmd}". Type "help" for a list of valid commands.`);
        break;
    }

    setTerminalHistory(prev => [...prev, ...response, '']);
    setCommandInput('');
  };

  const copyCode = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <TerminalIcon className="w-8 h-8 text-amber-400" /> C Engine Simulator & Compiler Hub
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Interact with your Vehicle Rental C business engine directly in browser or compile native binary
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl text-xs font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5" /> GCC 16.1.0 Ready
          </span>
        </div>
      </div>

      {/* Interactive Web Terminal Emulator */}
      <div className="bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl font-mono text-xs">
        {/* Terminal Titlebar */}
        <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="ml-2 text-slate-400 font-semibold text-[11px]">Apex Vehicle Rental C-Engine (x86_64-w64-mingw32-gcc)</span>
          </div>

          <button
            onClick={() => setTerminalHistory(['Terminal cleared. Type "help" for commands.', ''])}
            className="text-slate-400 hover:text-white text-[11px] flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" /> Clear
          </button>
        </div>

        {/* Terminal Screen */}
        <div className="p-5 min-h-[340px] max-h-[460px] overflow-y-auto space-y-1 text-slate-300">
          {terminalHistory.map((line, idx) => (
            <div
              key={idx}
              className={
                line.startsWith('***') || line.startsWith('===')
                  ? 'text-amber-400 font-bold'
                  : line.startsWith('>')
                  ? 'text-emerald-400 font-bold'
                  : line.startsWith('ID') || line.startsWith('Book ID') || line.startsWith('Log ID')
                  ? 'text-cyan-400 font-semibold'
                  : 'text-slate-300'
              }
            >
              {line}
            </div>
          ))}
        </div>

        {/* Terminal Input */}
        <form onSubmit={handleCommand} className="bg-slate-900/90 border-t border-slate-800 px-4 py-3 flex items-center gap-2">
          <span className="text-emerald-400 font-bold">apex-c-cli&gt;</span>
          <input
            type="text"
            placeholder="Type 'help', 'vehicles', 'status', 'rentals', 'customers', or 'compile'..."
            value={commandInput}
            onChange={e => setCommandInput(e.target.value)}
            className="flex-1 bg-transparent text-white font-mono text-xs focus:outline-none placeholder-slate-400"
            autoFocus
          />
          <button
            type="submit"
            className="px-3 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400"
          >
            Run
          </button>
        </form>
      </div>

      {/* Native C Compilation Guide */}
      <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-6 border border-slate-800 space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Code className="w-5 h-5 text-amber-400" /> Native C Executable Instructions
        </h2>

        <p className="text-xs text-slate-300">
          Your computer now has <strong className="text-amber-400">MinGW-w64 GCC 16.1.0</strong> installed. You can build and run the native high-performance standalone terminal executable anytime:
        </p>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-amber-300 space-y-1">
          <p className="text-slate-400"># 1. Navigate to the C source folder</p>
          <p>cd "c:\Users\SAMEER\web application\vehicle_rental_system"</p>
          <p className="text-slate-400 mt-2"># 2. Compile into optimized Windows executable</p>
          <p>gcc -std=c99 -Wall -Wextra -O2 main.c -o vehicle_rental_centre.exe</p>
          <p className="text-slate-400 mt-2"># 3. Run the application</p>
          <p>.\vehicle_rental_centre.exe</p>
        </div>
      </div>
    </div>
  );
};

export default Terminal;
