import React, { useState } from 'react';
import {
  Receipt,
  DollarSign,
  TrendingUp,
  Download,
  Calendar,
  FileText,
  CreditCard,
  CheckCircle2
} from 'lucide-react';
import { useStore } from '../store/StoreContext';

const Billing: React.FC = () => {
  const { transactions, rentals, maintenance, vehicles, customers } = useStore();
  const [filterType, setFilterType] = useState<string>('ALL');

  const completedRentals = rentals.filter(r => r.status === 'COMPLETED');
  const grossRevenue = completedRentals.reduce((sum, r) => sum + r.total_cost, 0);
  const totalMaintCost = maintenance.reduce((sum, m) => sum + m.cost, 0);
  const netProfit = grossRevenue - totalMaintCost;

  const depositsHeld = rentals
    .filter(r => r.status === 'ACTIVE')
    .reduce((sum, r) => sum + r.deposit_paid, 0);

  const filteredTransactions = transactions.filter(t => {
    if (filterType === 'ALL') return true;
    return t.type === filterType;
  });

  const handleExportReport = () => {
    const dateStr = new Date().toISOString().split('T')[0];
    let content = `================================================================================\n`;
    content += `         APEX AUTO WHEELS - COMPREHENSIVE BUSINESS PERFORMANCE REPORT           \n`;
    content += `                    Generated on: ${dateStr}                                    \n`;
    content += `================================================================================\n\n`;

    content += `1. EXECUTIVE FINANCIAL SUMMARY\n`;
    content += `   - Gross Rental Revenue       : $${grossRevenue.toFixed(2)}\n`;
    content += `   - Fleet Maintenance Expenses : $${totalMaintCost.toFixed(2)}\n`;
    content += `   - Net Operating Profit       : $${netProfit.toFixed(2)}\n`;
    content += `   - Active Security Deposits   : $${depositsHeld.toFixed(2)}\n\n`;

    content += `2. FLEET INVENTORY BREAKDOWN (${vehicles.length} Vehicles)\n`;
    vehicles.forEach(v => {
      content += `   [#${v.id}] ${v.brand} ${v.model} (${v.plate}) - $${v.daily_rate}/day - Status: ${v.status} - Odo: ${v.mileage} KM\n`;
    });
    content += `\n`;

    content += `3. COMPLETED RENTAL CONTRACTS (${completedRentals.length} Records)\n`;
    completedRentals.forEach(r => {
      content += `   Booking #${r.booking_id} | ${r.customer_name} | ${r.vehicle_info} | $${r.total_cost.toFixed(2)} | Period: ${r.start_date} to ${r.actual_return_date}\n`;
    });

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Apex_Business_Report_${dateStr}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Receipt className="w-8 h-8 text-amber-400" /> Financial Analytics & Transaction Ledger
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Cashflow ledger, POS settlements, security deposit accounting, and executive reporting
          </p>
        </div>

        <button
          onClick={handleExportReport}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 transition-all shadow-lg shadow-orange-500/20"
        >
          <Download className="w-4 h-4" /> Export Business Report (.txt)
        </button>
      </div>

      {/* Financial Executive Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Gross Rental Inflows</span>
          <div className="text-3xl font-black text-emerald-400 mt-2">${grossRevenue.toFixed(2)}</div>
          <p className="text-xs text-slate-400 mt-1">From {completedRentals.length} completed hires</p>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Fleet Service Outflows</span>
          <div className="text-3xl font-black text-rose-400 mt-2">${totalMaintCost.toFixed(2)}</div>
          <p className="text-xs text-slate-400 mt-1">Maintenance & repairs</p>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Net Operating Profit</span>
          <div className={`text-3xl font-black mt-2 ${netProfit >= 0 ? 'text-purple-400' : 'text-rose-400'}`}>
            ${netProfit.toFixed(2)}
          </div>
          <p className="text-xs text-slate-400 mt-1">Revenue minus maintenance</p>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Security Deposits Held</span>
          <div className="text-3xl font-black text-amber-400 mt-2">${depositsHeld.toFixed(2)}</div>
          <p className="text-xs text-slate-400 mt-1">Held for active on-road vehicles</p>
        </div>
      </div>

      {/* Transaction Ledger Table */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" /> General Cashflow & Transaction Ledger
          </h2>

          <div className="flex items-center gap-2 overflow-x-auto">
            {['ALL', 'RENTAL_DEPOSIT_ADVANCE', 'FINAL_SETTLEMENT', 'MAINTENANCE_EXPENSE'].map(type => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  filterType === type
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {type === 'ALL' ? 'All Transactions' : type.replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="text-[11px] uppercase tracking-wider text-slate-400 bg-slate-800/60 border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Tx ID</th>
                  <th className="px-5 py-3.5">Date</th>
                  <th className="px-5 py-3.5">Transaction Type</th>
                  <th className="px-5 py-3.5">Description</th>
                  <th className="px-5 py-3.5 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredTransactions.map((tx) => (
                  <tr key={tx.trans_id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-4 font-mono font-bold text-amber-400">#{tx.trans_id}</td>
                    <td className="px-5 py-4 text-xs text-slate-400">{tx.date}</td>
                    <td className="px-5 py-4">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          tx.type === 'FINAL_SETTLEMENT'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : tx.type === 'RENTAL_DEPOSIT_ADVANCE'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {tx.type.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-xs text-slate-200 font-medium">{tx.description}</td>
                    <td className="px-5 py-4 font-mono font-bold text-right">
                      <span className={tx.amount >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {tx.amount >= 0 ? `+$${tx.amount.toFixed(2)}` : `-$${Math.abs(tx.amount).toFixed(2)}`}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Billing;
