import React, { useState } from 'react';
import {
  Car,
  Search,
  Plus,
  Filter,
  Edit2,
  Trash2,
  CheckCircle,
  X,
  Fuel,
  Gauge,
  DollarSign
} from 'lucide-react';
import { useStore, type Vehicle } from '../store/StoreContext';

const Fleet: React.FC = () => {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);

  // Form State
  const [formData, setFormData] = useState<Omit<Vehicle, 'id'>>({
    plate: '',
    brand: '',
    model: '',
    year: 2024,
    category: 'Sedan',
    transmission: 'Automatic',
    fuel_type: 'Petrol',
    seats: 5,
    daily_rate: 60,
    hourly_rate: 12,
    deposit_req: 250,
    mileage: 12000,
    status: 'AVAILABLE'
  });

  const categories = ['ALL', 'Sedan', 'SUV', 'Luxury', 'Minivan', 'Motorcycle', 'Commercial'];
  const statuses = ['ALL', 'AVAILABLE', 'RENTED', 'MAINTENANCE', 'RESERVED'];

  const filteredVehicles = vehicles.filter(v => {
    if (v.is_deleted) return false;
    const matchesSearch =
      v.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.plate.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || v.category === selectedCategory;
    const matchesStatus = selectedStatus === 'ALL' || v.status === selectedStatus;
    return matchesSearch && matchesCat && matchesStatus;
  });

  const handleOpenAdd = () => {
    setEditingVehicle(null);
    setFormData({
      plate: '',
      brand: '',
      model: '',
      year: 2024,
      category: 'Sedan',
      transmission: 'Automatic',
      fuel_type: 'Petrol',
      seats: 5,
      daily_rate: 60,
      hourly_rate: 12,
      deposit_req: 250,
      mileage: 10000,
      status: 'AVAILABLE'
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (v: Vehicle) => {
    setEditingVehicle(v);
    setFormData({
      plate: v.plate,
      brand: v.brand,
      model: v.model,
      year: v.year,
      category: v.category,
      transmission: v.transmission,
      fuel_type: v.fuel_type,
      seats: v.seats,
      daily_rate: v.daily_rate,
      hourly_rate: v.hourly_rate,
      deposit_req: v.deposit_req,
      mileage: v.mileage,
      status: v.status
    });
    setIsAddModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingVehicle) {
      updateVehicle(editingVehicle.id, formData);
    } else {
      addVehicle(formData);
    }
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to remove this vehicle from active fleet?')) {
      const ok = deleteVehicle(id);
      if (!ok) {
        alert('Cannot remove vehicle that is currently marked as RENTED. Return vehicle first.');
      }
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Car className="w-8 h-8 text-amber-400" /> Fleet Inventory Management
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Total active fleet: <span className="text-amber-400 font-bold">{vehicles.filter(v => !v.is_deleted).length} vehicles</span>
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 transition-all shadow-lg shadow-orange-500/20"
        >
          <Plus className="w-4 h-4" /> Add New Vehicle
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-4 border border-slate-800 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              placeholder="Search by make, model, or plate (e.g., Toyota, SUV-4930)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700/80 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
            <div className="flex items-center gap-1.5 text-xs text-slate-400 pl-1">
              <Filter className="w-3.5 h-3.5 text-amber-400" /> Status:
            </div>
            {statuses.map(st => (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedStatus === st
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1 border-t border-slate-800/80">
          <span className="text-xs text-slate-400 mr-2">Category:</span>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-slate-700 text-amber-400 border border-amber-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Fleet Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredVehicles.map(veh => {
          const isAvailable = veh.status === 'AVAILABLE';
          const isRented = veh.status === 'RENTED';
          const isMaint = veh.status === 'MAINTENANCE';

          return (
            <div
              key={veh.id}
              className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 hover:border-slate-700/80 p-5 flex flex-col justify-between transition-all group shadow-sm hover:shadow-xl"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="px-2.5 py-1 rounded-lg bg-slate-800 font-mono text-xs font-bold text-amber-400 border border-slate-700">
                    {veh.plate}
                  </span>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold tracking-wide uppercase ${
                      isAvailable
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                        : isRented
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        : isMaint
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                    }`}
                  >
                    {veh.status}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                  {veh.brand} {veh.model}
                </h3>
                <p className="text-xs text-slate-400 mb-4">{veh.year} • {veh.category} • {veh.transmission}</p>

                {/* Specs badges */}
                <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 mb-4 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <Fuel className="w-3.5 h-3.5 text-amber-400" />
                    <span>{veh.fuel_type}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Gauge className="w-3.5 h-3.5 text-blue-400" />
                    <span>{veh.mileage.toLocaleString()} KM</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{veh.seats} Seats</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-purple-400" />
                    <span>Deposit: ${veh.deposit_req}</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-baseline justify-between pt-3 border-t border-slate-800 mb-4">
                  <div>
                    <span className="text-2xl font-black text-white">${veh.daily_rate}</span>
                    <span className="text-xs text-slate-400"> / day</span>
                  </div>
                  <span className="text-xs font-semibold text-slate-400">${veh.hourly_rate}/hour</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenEdit(veh)}
                    className="flex-1 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" /> Edit Specs
                  </button>

                  <button
                    onClick={() => handleDelete(veh.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-slate-800 transition-colors"
                    title="Decommission vehicle"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 md:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Car className="w-6 h-6 text-amber-400" />
                {editingVehicle ? 'Edit Vehicle Details & Rates' : 'Register New Fleet Vehicle'}
              </h2>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">License Plate No.</label>
                  <input
                    type="text"
                    required
                    value={formData.plate}
                    onChange={e => setFormData({ ...formData, plate: e.target.value.toUpperCase() })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-sm focus:border-amber-400"
                    placeholder="e.g. CAR-8821"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Make / Brand</label>
                  <input
                    type="text"
                    required
                    value={formData.brand}
                    onChange={e => setFormData({ ...formData, brand: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                    placeholder="e.g. Toyota, BMW"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Model</label>
                  <input
                    type="text"
                    required
                    value={formData.model}
                    onChange={e => setFormData({ ...formData, model: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                    placeholder="e.g. Camry SE, 530i"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Year</label>
                  <input
                    type="number"
                    min="1990"
                    max="2027"
                    required
                    value={formData.year}
                    onChange={e => setFormData({ ...formData, year: parseInt(e.target.value) || 2024 })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                  >
                    <option value="Sedan">Sedan</option>
                    <option value="SUV">SUV</option>
                    <option value="Luxury">Luxury</option>
                    <option value="Minivan">Minivan</option>
                    <option value="Motorcycle">Motorcycle</option>
                    <option value="Commercial">Commercial / Truck</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Fuel Type</label>
                  <select
                    value={formData.fuel_type}
                    onChange={e => setFormData({ ...formData, fuel_type: e.target.value as any })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                  >
                    <option value="Petrol">Petrol</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Electric">Electric</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Transmission</label>
                  <select
                    value={formData.transmission}
                    onChange={e => setFormData({ ...formData, transmission: e.target.value as any })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                  >
                    <option value="Automatic">Automatic</option>
                    <option value="Manual">Manual</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Seating Capacity</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    required
                    value={formData.seats}
                    onChange={e => setFormData({ ...formData, seats: parseInt(e.target.value) || 5 })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Daily Rental Rate ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={formData.daily_rate}
                    onChange={e => setFormData({ ...formData, daily_rate: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Hourly Rate ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={formData.hourly_rate}
                    onChange={e => setFormData({ ...formData, hourly_rate: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Security Deposit Req ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="10"
                    required
                    value={formData.deposit_req}
                    onChange={e => setFormData({ ...formData, deposit_req: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Current Odometer (KM)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.mileage}
                    onChange={e => setFormData({ ...formData, mileage: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Vehicle Status</label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-amber-400"
                >
                  <option value="AVAILABLE">AVAILABLE (Ready for hire)</option>
                  <option value="MAINTENANCE">MAINTENANCE (Under repair / servicing)</option>
                  <option value="RESERVED">RESERVED (Booking held)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20"
                >
                  {editingVehicle ? 'Save Vehicle Updates' : 'Register Vehicle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Fleet;
