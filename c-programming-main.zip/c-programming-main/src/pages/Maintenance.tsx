import React, { useState } from 'react';
import {
  Wrench,
  Plus,
  ShieldAlert,
  Calendar,
  DollarSign,
  Gauge,
  X,
  Fuel,
  CheckCircle2
} from 'lucide-react';
import { useStore } from '../store/StoreContext';

const Maintenance: React.FC = () => {
  const { vehicles, maintenance, logMaintenance } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [selectedVehId, setSelectedVehId] = useState<number>(vehicles[0]?.id || 0);
  const [serviceDate, setServiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [serviceType, setServiceType] = useState('Engine Oil & Filter Change');
  const [cost, setCost] = useState<number>(85);
  const [odometer, setOdometer] = useState<number>(vehicles[0]?.mileage || 15000);
  const [vendor, setVendor] = useState('Apex Auto Care Express');
  const [description, setDescription] = useState('Full synthetic oil and filter change with 21-point inspection');
  const [newStatus, setNewStatus] = useState<'AVAILABLE' | 'MAINTENANCE'>('AVAILABLE');

  const activeVehicles = vehicles.filter(v => !v.is_deleted);
  const totalMaintCost = maintenance.reduce((sum, m) => sum + m.cost, 0);

  const handleOpenLog = (vehId?: number) => {
    if (vehId) {
      const v = vehicles.find(item => item.id === vehId);
      if (v) {
        setSelectedVehId(v.id);
        setOdometer(v.mileage);
      }
    } else if (vehicles.length > 0) {
      setSelectedVehId(vehicles[0].id);
      setOdometer(vehicles[0].mileage);
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    logMaintenance({
      vehicle_id: selectedVehId,
      date: serviceDate,
      service_type: serviceType,
      cost,
      description,
      odometer_at_service: odometer,
      vendor_mechanic: vendor,
      new_status: newStatus
    });
    setIsModalOpen(false);
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Wrench className="w-8 h-8 text-amber-400" /> Fleet Maintenance & Health Tracker
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Track scheduled oil changes, tire rotations, brake overhauls, and routine service milestones
          </p>
        </div>

        <button
          onClick={() => handleOpenLog()}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 transition-all shadow-lg shadow-orange-500/20"
        >
          <Plus className="w-4 h-4" /> Log Service Event
        </button>
      </div>

      {/* Fleet Health Overview Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Service Events</span>
          <div className="text-3xl font-extrabold text-white mt-2">{maintenance.length}</div>
          <p className="text-xs text-slate-400 mt-1">Lifetime fleet service operations</p>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Maintenance Cost</span>
          <div className="text-3xl font-extrabold text-rose-400 mt-2">${totalMaintCost.toFixed(2)}</div>
          <p className="text-xs text-slate-400 mt-1">Recorded maintenance expenditure</p>
        </div>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl p-5 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Fleet Service Interval</span>
          <div className="text-3xl font-extrabold text-amber-400 mt-2">10,000 KM</div>
          <p className="text-xs text-slate-400 mt-1">Automated routine service threshold</p>
        </div>
      </div>

      {/* Fleet Health Alert Cards */}
      <div className="space-y-3">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-amber-400" /> Fleet Health Status (By Vehicle)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {activeVehicles.map((veh) => {
            const km = veh.mileage;
            const due = (km % 10000) > 8500;
            const isMaint = veh.status === 'MAINTENANCE';

            return (
              <div
                key={veh.id}
                className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 p-4 flex flex-col justify-between"
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="font-bold text-white text-sm">{veh.brand} {veh.model}</h3>
                    <span className="font-mono text-xs text-slate-400">[{veh.plate}]</span>
                  </div>

                  {isMaint ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                      Under Repair
                    </span>
                  ) : due ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      Service Due Soon
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      Healthy
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400 py-2 border-t border-slate-800/80 my-2">
                  <span className="flex items-center gap-1"><Gauge className="w-3.5 h-3.5 text-blue-400" /> {veh.mileage.toLocaleString()} KM</span>
                  <span className="flex items-center gap-1"><Fuel className="w-3.5 h-3.5 text-amber-400" /> {veh.fuel_type}</span>
                </div>

                <button
                  onClick={() => handleOpenLog(veh.id)}
                  className="w-full py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                >
                  Log Service for this Vehicle
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Maintenance History Table */}
      <div className="space-y-3 pt-2">
        <h2 className="text-lg font-bold text-white">Maintenance History & Archives</h2>

        <div className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="text-[11px] uppercase tracking-wider text-slate-400 bg-slate-800/60 border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Log ID</th>
                  <th className="px-5 py-3.5">Vehicle</th>
                  <th className="px-5 py-3.5">Service Type</th>
                  <th className="px-5 py-3.5">Service Date</th>
                  <th className="px-5 py-3.5">Odometer</th>
                  <th className="px-5 py-3.5">Vendor / Workshop</th>
                  <th className="px-5 py-3.5 text-right">Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {maintenance.map((m) => (
                  <tr key={m.log_id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-4 font-mono font-bold text-amber-400">#{m.log_id}</td>
                    <td className="px-5 py-4 font-semibold text-white">{m.vehicle_info}</td>
                    <td className="px-5 py-4 text-xs text-slate-200 font-medium">{m.service_type}</td>
                    <td className="px-5 py-4 text-xs text-slate-400">{m.date}</td>
                    <td className="px-5 py-4 font-mono text-xs text-slate-300">{m.odometer_at_service.toLocaleString()} KM</td>
                    <td className="px-5 py-4 text-xs text-slate-400">{m.vendor_mechanic}</td>
                    <td className="px-5 py-4 font-mono font-bold text-rose-400 text-right">${m.cost.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Log Maintenance Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-6 md:p-8 shadow-2xl space-y-6 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Wrench className="w-6 h-6 text-amber-400" /> Log Vehicle Maintenance Event
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Select Serviced Vehicle</label>
                <select
                  value={selectedVehId}
                  onChange={e => {
                    const id = parseInt(e.target.value);
                    setSelectedVehId(id);
                    const v = vehicles.find(item => item.id === id);
                    if (v) setOdometer(v.mileage);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                >
                  {activeVehicles.map(v => (
                    <option key={v.id} value={v.id}>
                      {v.brand} {v.model} [{v.plate}] — {v.mileage.toLocaleString()} KM
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Service Date</label>
                  <input
                    type="date"
                    required
                    value={serviceDate}
                    onChange={e => setServiceDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">Total Service Cost ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={cost}
                    onChange={e => setCost(parseFloat(e.target.value) || 0)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Service Type</label>
                <select
                  value={serviceType}
                  onChange={e => setServiceType(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                >
                  <option value="Engine Oil & Filter Change">Engine Oil & Filter Change</option>
                  <option value="Brake System Service">Brake System Service</option>
                  <option value="Tire Replacement & Balance">Tire Replacement & Balance</option>
                  <option value="Multi-Point Safety Inspection">Multi-Point Safety Inspection</option>
                  <option value="Bodywork & Detailing">Bodywork & Detailing</option>
                  <option value="Mechanical Repair">Mechanical Repair</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Odometer Reading at Service (KM)</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={odometer}
                  onChange={e => setOdometer(parseFloat(e.target.value) || 0)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Vendor / Workshop Name</label>
                <input
                  type="text"
                  required
                  value={vendor}
                  onChange={e => setVendor(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  placeholder="e.g. Apex Auto Care North"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Service Notes / Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                  placeholder="Details of parts replaced, etc."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1">Vehicle Status After Service</label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm"
                >
                  <option value="AVAILABLE">AVAILABLE (Ready for hire)</option>
                  <option value="MAINTENANCE">MAINTENANCE (Work ongoing / waiting for parts)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20"
                >
                  Record Maintenance Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Maintenance;
