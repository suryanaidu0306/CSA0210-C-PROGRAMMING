import { useState } from 'react';
import { useStore, type Medicine } from '../store/StoreContext';
import { ShoppingCart, Plus, Minus, Trash2, Search, Receipt } from 'lucide-react';
import { motion } from 'framer-motion';

export default function POS() {
  const { medicines, checkout } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<{ medicine: Medicine; quantity: number }[]>([]);

  const filteredMedicines = medicines.filter(m => 
    m.stock > 0 && 
    (m.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
     m.category.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const addToCart = (med: Medicine) => {
    const existingItem = cart.find(item => item.medicine.id === med.id);
    if (existingItem) {
      if (existingItem.quantity < med.stock) {
        setCart(cart.map(item => 
          item.medicine.id === med.id ? { ...item, quantity: item.quantity + 1 } : item
        ));
      }
    } else {
      setCart([...cart, { medicine: med, quantity: 1 }]);
    }
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.medicine.id === id) {
        const newQty = item.quantity + delta;
        if (newQty > 0 && newQty <= item.medicine.stock) {
          return { ...item, quantity: newQty };
        }
      }
      return item;
    }));
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.medicine.id !== id));
  };

  const totalAmount = cart.reduce((sum, item) => sum + (item.medicine.price * item.quantity), 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    checkout(cart);
    setCart([]);
    alert('Checkout successful! Stock has been updated.');
  };

  return (
    <div className="p-8 h-full flex flex-col md:flex-row gap-6 w-full">
      {/* Products Section */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h2 className="text-3xl font-bold text-slate-100">Point of Sale</h2>
          <p className="text-slate-400 mt-1">Select medicines to bill.</p>
        </motion.div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Search available medicines..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-800/50 border border-slate-700/50 rounded-xl py-3 pl-11 pr-4 text-slate-200 placeholder-slate-400 focus:outline-none focus:border-neon-blue transition-colors text-lg"
          />
        </div>

        <div className="flex-1 overflow-y-auto pr-2 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 auto-rows-max">
          {filteredMedicines.map(med => (
            <motion.div
              key={med.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.02 }}
              onClick={() => addToCart(med)}
              className="glass-card p-4 rounded-xl cursor-pointer hover:border-neon-blue/50 transition-colors flex flex-col h-32 justify-between"
            >
              <div>
                <h3 className="font-bold text-slate-200 truncate">{med.name}</h3>
                <p className="text-sm text-slate-400">{med.category}</p>
              </div>
              <div className="flex justify-between items-end">
                <span className="text-lg font-bold text-neon-green">${med.price.toFixed(2)}</span>
                <span className="text-xs bg-slate-800 px-2 py-1 rounded text-slate-300 border border-slate-700">
                  Stock: {med.stock}
                </span>
              </div>
            </motion.div>
          ))}
          {filteredMedicines.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-500 glass-card rounded-xl">
              No available medicines found.
            </div>
          )}
        </div>
      </div>

      {/* Cart Section */}
      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-full md:w-96 glass-card rounded-2xl flex flex-col border-slate-700/50 overflow-hidden"
      >
        <div className="p-6 border-b border-slate-700/50 bg-slate-800/20 flex items-center space-x-3">
          <ShoppingCart className="text-neon-blue" />
          <h3 className="text-xl font-bold text-slate-100">Current Order</h3>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-4">
              <ShoppingCart size={48} className="opacity-20" />
              <p>Cart is empty</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.medicine.id} className="bg-slate-800/50 border border-slate-700/50 p-4 rounded-xl">
                <div className="flex justify-between mb-2">
                  <span className="font-medium text-slate-200 truncate pr-2">{item.medicine.name}</span>
                  <span className="font-bold text-slate-300">${(item.medicine.price * item.quantity).toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-3 bg-slate-900 rounded-lg p-1 border border-slate-700">
                    <button 
                      onClick={() => updateQuantity(item.medicine.id, -1)}
                      className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="w-6 text-center font-medium text-slate-200">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.medicine.id, 1)}
                      className="p-1 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-colors"
                      disabled={item.quantity >= item.medicine.stock}
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item.medicine.id)}
                    className="text-slate-500 hover:text-neon-red transition-colors p-2"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-6 border-t border-slate-700/50 bg-slate-800/30">
          <div className="flex justify-between mb-4 text-lg">
            <span className="text-slate-400">Total</span>
            <span className="font-bold text-2xl text-neon-green">${totalAmount.toFixed(2)}</span>
          </div>
          <button 
            onClick={handleCheckout}
            disabled={cart.length === 0}
            className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center space-x-2 transition-all shadow-lg ${
              cart.length > 0 
                ? 'bg-neon-blue hover:bg-blue-600 text-white shadow-neon-blue/20' 
                : 'bg-slate-700 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Receipt size={24} />
            <span>Process Payment</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
