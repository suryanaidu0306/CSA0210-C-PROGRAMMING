import React, { useState } from 'react';
import { useStore, type Medicine } from '../store/StoreContext';
import { Plus, Search, Edit2, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Inventory() {
  const { medicines, addMedicine, updateMedicine, deleteMedicine } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    batch: '',
    expiry: '',
    price: '',
    stock: ''
  });

  const filteredMedicines = medicines.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const medicineData = {
      name: formData.name,
      category: formData.category,
      batch: formData.batch,
      expiry: formData.expiry,
      price: parseFloat(formData.price),
      stock: parseInt(formData.stock, 10)
    };

    if (editingId) {
      updateMedicine(editingId, medicineData);
    } else {
      addMedicine(medicineData);
    }

    closeModal();
  };

  const openModal = (med?: Medicine) => {
    if (med) {
      setFormData({
        name: med.name,
        category: med.category,
        batch: med.batch,
        expiry: med.expiry,
        price: med.price.toString(),
        stock: med.stock.toString()
      });
      setEditingId(med.id);
    } else {
      setFormData({ name: '', category: '', batch: '', expiry: '', price: '', stock: '' });
      setEditingId(null);
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingId(null);
  };

  return (
    <div className="p-8 h-full flex flex-col w-full">
      <div className="flex justify-between items-end mb-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <h2 className="text-3xl font-bold text-slate-100">Inventory</h2>
          <p className="text-slate-400 mt-1">Manage medicines and stocks.</p>
        </motion.div>
        
        <motion.button
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => openModal()}
          className="bg-neon-blue hover:bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium flex items-center space-x-2 transition-colors shadow-lg shadow-neon-blue/20"
        >
          <Plus size={20} />
          <span>Add Medicine</span>
        </motion.button>
      </div>

      <div className="glass-card rounded-2xl flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-700/50 flex space-x-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="Search medicines..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800/50 border border-slate-700/50 rounded-xl py-2 pl-10 pr-4 text-slate-200 placeholder-slate-400 focus:outline-none focus:border-neon-blue transition-colors"
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <table className="w-full text-left text-sm">
            <thead className="text-slate-400 sticky top-0 bg-background/95 backdrop-blur-md">
              <tr>
                <th className="pb-4 font-medium px-4">Name</th>
                <th className="pb-4 font-medium px-4">Category</th>
                <th className="pb-4 font-medium px-4">Batch No.</th>
                <th className="pb-4 font-medium px-4">Expiry</th>
                <th className="pb-4 font-medium px-4 text-right">Price</th>
                <th className="pb-4 font-medium px-4 text-right">Stock</th>
                <th className="pb-4 font-medium px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {filteredMedicines.map((med) => (
                <motion.tr 
                  key={med.id} 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  className="hover:bg-slate-800/30 transition-colors"
                >
                  <td className="py-4 px-4 font-medium text-slate-200">{med.name}</td>
                  <td className="py-4 px-4 text-slate-400">{med.category}</td>
                  <td className="py-4 px-4 text-slate-400">{med.batch}</td>
                  <td className="py-4 px-4 text-slate-400">{med.expiry}</td>
                  <td className="py-4 px-4 text-right font-medium text-slate-200">${med.price.toFixed(2)}</td>
                  <td className="py-4 px-4 text-right">
                    <span className={`px-2 py-1 rounded-md text-xs font-bold ${med.stock < 20 ? 'bg-neon-red/20 text-neon-red' : 'bg-neon-green/20 text-neon-green'}`}>
                      {med.stock}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-center space-x-3">
                    <button onClick={() => openModal(med)} className="text-neon-blue hover:text-blue-400 transition-colors">
                      <Edit2 size={18} />
                    </button>
                    <button onClick={() => deleteMedicine(med.id)} className="text-neon-red hover:text-red-400 transition-colors">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </motion.tr>
              ))}
              {filteredMedicines.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No medicines found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-slate-700 p-6 rounded-2xl w-full max-w-md shadow-2xl"
            >
              <h3 className="text-2xl font-bold mb-4 text-slate-100">
                {editingId ? 'Edit Medicine' : 'Add Medicine'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Name</label>
                  <input required type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-neon-blue focus:outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Category</label>
                    <input required type="text" value={formData.category} onChange={(e) => setFormData({...formData, category: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-neon-blue focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Batch No.</label>
                    <input required type="text" value={formData.batch} onChange={(e) => setFormData({...formData, batch: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-neon-blue focus:outline-none" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Expiry Date</label>
                    <input required type="date" value={formData.expiry} onChange={(e) => setFormData({...formData, expiry: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-neon-blue focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Price ($)</label>
                    <input required type="number" step="0.01" value={formData.price} onChange={(e) => setFormData({...formData, price: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-neon-blue focus:outline-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Initial Stock</label>
                  <input required type="number" value={formData.stock} onChange={(e) => setFormData({...formData, stock: e.target.value})} className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:border-neon-blue focus:outline-none" />
                </div>
                <div className="flex justify-end space-x-3 pt-4 border-t border-slate-700/50 mt-6">
                  <button type="button" onClick={closeModal} className="px-4 py-2 rounded-xl text-slate-300 hover:bg-slate-800 transition-colors">
                    Cancel
                  </button>
                  <button type="submit" className="px-4 py-2 rounded-xl bg-neon-blue text-white hover:bg-blue-600 transition-colors font-medium shadow-lg shadow-neon-blue/20">
                    {editingId ? 'Save Changes' : 'Add Medicine'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
