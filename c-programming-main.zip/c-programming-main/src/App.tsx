import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { StoreProvider } from './store/StoreContext';
import Dashboard from './pages/Dashboard';
import Fleet from './pages/Fleet';
import Rentals from './pages/Rentals';
import Customers from './pages/Customers';
import Maintenance from './pages/Maintenance';
import Billing from './pages/Billing';
import Terminal from './pages/Terminal';
import Login from './pages/Login';
import ProtectedRoute from './components/ProtectedRoute';
import type { ReactNode } from 'react';

function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen overflow-hidden bg-slate-950 text-slate-100 font-sans">
      <Sidebar />
      <main className="flex-1 flex flex-col relative w-full h-full overflow-hidden">
        {/* Top Navbar Mobile */}
        <div className="md:hidden p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900">
          <h1 className="text-lg font-bold text-white tracking-wider">
            Apex <span className="text-amber-400">Wheels</span>
          </h1>
        </div>

        {/* Decorative Ambient Background */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/5 blur-[140px] rounded-full pointer-events-none" />
        <div className="absolute bottom-0 right-10 w-96 h-96 bg-orange-500/5 blur-[140px] rounded-full pointer-events-none" />

        <div className="flex-1 z-10 w-full overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/*" element={
            <ProtectedRoute>
              <AppLayout>
                <Routes>
                  <Route path="/" element={<Dashboard />} />
                  <Route path="/fleet" element={<Fleet />} />
                  <Route path="/rentals" element={<Rentals />} />
                  <Route path="/customers" element={<Customers />} />
                  <Route path="/maintenance" element={<Maintenance />} />
                  <Route path="/billing" element={<Billing />} />
                  <Route path="/terminal" element={<Terminal />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </AppLayout>
            </ProtectedRoute>
          } />
        </Routes>
      </BrowserRouter>
    </StoreProvider>
  );
}

export default App;
