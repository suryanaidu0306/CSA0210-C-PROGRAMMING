@echo off
title Apex Auto Wheels - Vehicle Rental Centre Launcher
color 0B
cls
echo ===============================================================================
echo       *** APEX AUTO WHEELS - VEHICLE RENTAL CENTRE LAUNCHER ***
echo ===============================================================================
echo.
echo  [1] Launch Modern Web Application (Localhost in Browser)
echo  [2] Launch Native C Terminal Software (vehicle_rental_centre.exe)
echo  [3] Launch BOTH Web App & C Terminal simultaneously
echo  [4] Recompile C Software from main.c
echo  [5] Exit
echo.
echo ===============================================================================
set /p choice="Enter your choice (1-5): "

if "%choice%"=="1" goto launch_web
if "%choice%"=="2" goto launch_c
if "%choice%"=="3" goto launch_both
if "%choice%"=="4" goto recompile_c
if "%choice%"=="5" goto exit_launcher

:launch_web
echo.
echo [INFO] Starting Web Application on http://localhost:5173/ ...
start cmd /k "cd /d "%~dp0" && npm run dev"
timeout /t 2 >nul
start http://localhost:5173/
goto end

:launch_c
echo.
echo [INFO] Launching Native C Application...
start cmd /k "cd /d "%~dp0vehicle_rental_system" && vehicle_rental_centre.exe"
goto end

:launch_both
echo.
echo [INFO] Starting Web Server & Opening Browser...
start cmd /k "cd /d "%~dp0" && npm run dev"
timeout /t 2 >nul
start http://localhost:5173/
echo [INFO] Starting Native C Application...
start cmd /k "cd /d "%~dp0vehicle_rental_system" && vehicle_rental_centre.exe"
goto end

:recompile_c
echo.
echo [INFO] Recompiling main.c using GCC...
cd /d "%~dp0vehicle_rental_system"
gcc -std=c99 -Wall -Wextra -O2 main.c -o vehicle_rental_centre.exe
if %ERRORLEVEL% EQU 0 (
    echo [SUCCESS] Successfully compiled vehicle_rental_centre.exe!
    pause
    start cmd /k "vehicle_rental_centre.exe"
) else (
    echo [ERROR] Compilation failed.
    pause
)
goto end

:exit_launcher
exit

:end
