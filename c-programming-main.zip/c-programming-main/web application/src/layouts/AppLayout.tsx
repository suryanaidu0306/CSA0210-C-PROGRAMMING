import React from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { 
  Shield, 
  LayoutDashboard, 
  KeyRound, 
  BookOpenCheck, 
  BarChart3, 
  Settings, 
  Menu,
  X,
  ArrowLeft,
  User,
  LogOut,
  ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/analyzer', label: 'Password Analyzer', icon: Shield },
  { path: '/generator', label: 'Password Generator', icon: KeyRound },
  { path: '/awareness', label: 'Security Awareness', icon: BookOpenCheck },
  { path: '/statistics', label: 'Statistics', icon: BarChart3 },
  { path: '/settings', label: 'Settings', icon: Settings },
];

export default function AppLayout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isProfileOpen, setIsProfileOpen] = React.useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Close menus on route change
  React.useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsProfileOpen(false);
  }, [location.pathname]);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        className={`fixed inset-y-0 left-0 z-50 w-64 transform flex-col bg-card border-r border-slate-800 transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        } flex`}
      >
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <div className="flex items-center gap-3 text-neon-blue">
            <Shield size={32} />
            <span className="text-lg font-bold text-white tracking-wider">SecuriAuth</span>
          </div>
          <button
            className="lg:hidden text-slate-400 hover:text-white"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={24} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-6 px-4 space-y-2 custom-scrollbar">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group ${
                  isActive
                    ? 'bg-neon-blue/10 text-neon-blue shadow-[0_0_15px_rgba(59,130,246,0.15)]'
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                }`
              }
            >
              <item.icon
                size={20}
                className="transition-transform duration-200 group-hover:scale-110"
              />
              <span className="font-medium">{item.label}</span>
            </NavLink>
          ))}
        </nav>
      </motion.aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Navbar */}
        <header className="flex-shrink-0 h-16 bg-card/80 backdrop-blur-md border-b border-slate-800 flex items-center justify-between px-6 lg:px-10 z-10">
          <div className="flex items-center gap-4">
            <button
              className="lg:hidden text-slate-400 hover:text-white"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu size={24} />
            </button>
            <button 
              onClick={() => navigate(-1)}
              className="text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
              title="Go Back"
            >
              <ArrowLeft size={20} />
              <span className="hidden sm:inline text-sm font-medium">Back</span>
            </button>
            <h1 className="text-xl font-semibold text-white truncate hidden md:block border-l border-slate-700 pl-4 ml-2">
              Password Strength & Awareness System
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 text-sm text-slate-400">
              <Shield size={16} className="text-neon-green" />
              <span>System Secured</span>
            </div>
            {/* User Profile Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="flex items-center gap-2 focus:outline-none group"
              >
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-neon-blue to-neon-purple flex items-center justify-center text-white font-bold shadow-lg shadow-neon-blue/20 ring-2 ring-transparent group-hover:ring-neon-blue transition-all">
                  U
                </div>
                <ChevronDown size={16} className={`text-slate-400 transition-transform duration-200 hidden sm:block ${isProfileOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {isProfileOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-40" 
                      onClick={() => setIsProfileOpen(false)}
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 mt-3 w-56 bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-xl shadow-2xl shadow-black/50 overflow-hidden z-50"
                    >
                      <div className="px-4 py-3 border-b border-slate-800 bg-slate-800/30">
                        <p className="text-sm font-semibold text-white">System Admin</p>
                        <p className="text-xs text-slate-400 mt-0.5 truncate">admin@securiauth.com</p>
                      </div>
                      <div className="py-2">
                        <button 
                          onClick={() => { setIsProfileOpen(false); navigate('/settings'); }}
                          className="w-full px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800 flex items-center gap-3 transition-colors"
                        >
                          <User size={16} className="text-neon-blue" />
                          User Profile
                        </button>
                        <button 
                          onClick={() => { setIsProfileOpen(false); navigate('/settings'); }}
                          className="w-full px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800 flex items-center gap-3 transition-colors"
                        >
                          <Settings size={16} className="text-slate-400" />
                          Preferences
                        </button>
                      </div>
                      <div className="py-2 border-t border-slate-800">
                        <button 
                          onClick={() => setIsProfileOpen(false)}
                          className="w-full px-4 py-2 text-sm text-slate-300 hover:bg-neon-red/10 hover:text-neon-red flex items-center gap-3 transition-colors"
                        >
                          <LogOut size={16} />
                          Sign Out
                        </button>
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto relative p-4 md:p-6 lg:p-8">
          {/* Decorative Background Elements */}
          <div className="absolute top-0 left-0 w-full h-96 bg-neon-blue/5 blur-[120px] rounded-full pointer-events-none" />
          <div className="absolute bottom-0 right-0 w-3/4 h-96 bg-neon-purple/5 blur-[120px] rounded-full pointer-events-none" />
          
          {/* Animate Page Transitions */}
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="relative z-10 h-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
