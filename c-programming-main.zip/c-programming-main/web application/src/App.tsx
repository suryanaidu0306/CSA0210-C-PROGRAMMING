import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AppLayout from './layouts/AppLayout';

import LandingPage from './pages/LandingPage';
import SplashScreen from './pages/SplashScreen';

import Dashboard from './pages/Dashboard';
import Analyzer from './pages/Analyzer';
import { 
  AnalyzerEntropy, 
  AnalyzerPatterns, 
  AnalyzerCrackTime, 
  AnalyzerSuggestions 
} from './pages/AnalyzerSubScreens';

import Generator from './pages/Generator';

import Awareness from './pages/Awareness';
import AwarenessQuiz from './pages/AwarenessQuiz';

import Statistics from './pages/Statistics';

import Settings from './pages/Settings';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Splash Screen at root */}
        <Route path="/" element={<SplashScreen />} />
        
        {/* Original Landing Page */}
        <Route path="/home" element={<LandingPage />} />
        
        {/* App with Sidebar Layout */}
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/analyzer" element={<Analyzer />}>
            <Route path="entropy" element={<AnalyzerEntropy />} />
            <Route path="patterns" element={<AnalyzerPatterns />} />
            <Route path="common" element={<AnalyzerPatterns />} /> {/* Sharing patterns view for common words */}
            <Route path="crack-time" element={<AnalyzerCrackTime />} />
            <Route path="suggestions" element={<AnalyzerSuggestions />} />
          </Route>
          <Route path="/generator" element={<Generator />} />
          <Route path="/awareness" element={<Awareness />}>
            <Route path="quiz" element={<AwarenessQuiz />} />
          </Route>
          <Route path="/statistics" element={<Statistics />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
        
        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
