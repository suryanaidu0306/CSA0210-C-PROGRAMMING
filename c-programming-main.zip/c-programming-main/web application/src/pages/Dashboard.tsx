import React from 'react';
import { motion } from 'framer-motion';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Activity, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

const mockActivityData = [
  { name: 'Mon', strength: 40, entropy: 24 },
  { name: 'Tue', strength: 60, entropy: 48 },
  { name: 'Wed', strength: 55, entropy: 40 },
  { name: 'Thu', strength: 80, entropy: 72 },
  { name: 'Fri', strength: 95, entropy: 90 },
  { name: 'Sat', strength: 70, entropy: 60 },
  { name: 'Sun', strength: 85, entropy: 75 },
];

const mockRecentAnalyses = [
  { id: 1, type: 'Weak', score: 20, time: '2 mins ago', icon: AlertTriangle, color: 'text-neon-red' },
  { id: 2, type: 'Strong', score: 85, time: '1 hour ago', icon: ShieldCheck, color: 'text-neon-green' },
  { id: 3, type: 'Fair', score: 50, time: '3 hours ago', icon: Activity, color: 'text-neon-purple' },
  { id: 4, type: 'Compromised', score: 10, time: '5 hours ago', icon: ShieldAlert, color: 'text-neon-red' },
];

const StatCard = ({ title, value, change, trend, icon: Icon, delay }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className="glass-card p-6 rounded-2xl flex items-start justify-between"
  >
    <div>
      <p className="text-slate-400 text-sm font-medium mb-1">{title}</p>
      <h3 className="text-3xl font-bold text-white mb-2">{value}</h3>
      <div className={`flex items-center text-sm ${trend === 'up' ? 'text-neon-green' : 'text-neon-red'}`}>
        {trend === 'up' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
        <span className="ml-1">{change}</span>
      </div>
    </div>
    <div className="p-3 bg-slate-800/50 rounded-xl">
      <Icon size={24} className="text-neon-blue" />
    </div>
  </motion.div>
);

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Security Overview</h1>
        <p className="text-slate-400">Monitor your authentication health and recent password analysis metrics.</p>
      </header>

      {/* Top Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Average Password Strength" 
          value="72%" 
          change="+5.2% this week" 
          trend="up" 
          icon={ShieldCheck} 
          delay={0.1}
        />
        <StatCard 
          title="Weak Passwords Detected" 
          value="14" 
          change="-2 from last week" 
          trend="down" 
          icon={ShieldAlert} 
          delay={0.2}
        />
        <StatCard 
          title="Avg Entropy (Bits)" 
          value="64.5" 
          change="+12.4 this week" 
          trend="up" 
          icon={Activity} 
          delay={0.3}
        />
        <StatCard 
          title="Security Awareness Score" 
          value="88/100" 
          change="Top 15% of users" 
          trend="up" 
          icon={AlertTriangle} 
          delay={0.4}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart Section */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="glass-card p-6 rounded-2xl lg:col-span-2"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Strength vs Entropy Trend</h2>
            <select className="bg-slate-800/50 border border-slate-700 text-slate-300 text-sm rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-neon-blue">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockActivityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorStrength" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorEntropy" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0B1120', borderColor: '#334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Area type="monotone" dataKey="strength" stroke="#3B82F6" strokeWidth={3} fillOpacity={1} fill="url(#colorStrength)" />
                <Area type="monotone" dataKey="entropy" stroke="#8B5CF6" strokeWidth={3} fillOpacity={1} fill="url(#colorEntropy)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Recent Activity List */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="glass-card p-6 rounded-2xl flex flex-col"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Recent Analyses</h2>
            <button className="text-sm text-neon-blue hover:underline">View All</button>
          </div>
          <div className="flex-1 space-y-4">
            {mockRecentAnalyses.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-800/30 transition-colors border border-transparent hover:border-slate-700/50">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-slate-800/50 ${item.color}`}>
                    <item.icon size={18} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">{item.type} Password</p>
                    <p className="text-xs text-slate-400">{item.time}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-lg font-bold text-white">{item.score}</span>
                  <span className="text-xs text-slate-400 block">/100</span>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-neon-blue/10 to-neon-purple/10 border border-slate-700/50">
            <h3 className="text-sm font-bold text-white mb-1">Quick Action</h3>
            <p className="text-xs text-slate-400 mb-3">2 weak passwords require your attention.</p>
            <button className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-medium transition-colors border border-slate-600">
              Review Now
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
