import React from 'react';
import { motion } from 'framer-motion';
import { Lightbulb, BookOpen, Fingerprint, BrainCircuit } from 'lucide-react';

export default function Insights() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Research Insights</h1>
        <p className="text-slate-400">Deep dives into the science of passwords, human behavior, and cryptographic entropy.</p>
      </header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-8 rounded-2xl border-l-4 border-l-neon-purple"
      >
        <div className="flex items-center gap-3 mb-6">
          <BookOpen className="text-neon-purple" size={28} />
          <h2 className="text-2xl font-bold text-white">The Mathematics of Entropy</h2>
        </div>
        <p className="text-slate-300 leading-relaxed mb-4">
          Password entropy is a measurement of how unpredictable a password is. It is calculated in "bits". The formula for entropy is:
        </p>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-700/50 font-mono text-center text-neon-blue mb-4">
          E = L × log₂(R)
        </div>
        <p className="text-slate-300 leading-relaxed mb-4">
          Where <strong className="text-white">E</strong> is Entropy, <strong className="text-white">L</strong> is the length of the password, and <strong className="text-white">R</strong> is the pool of possible characters (e.g., 26 for lowercase letters, 94 for all standard keyboard characters).
        </p>
        <div className="bg-neon-purple/10 p-4 rounded-xl border border-neon-purple/20">
          <h4 className="text-white font-bold mb-2">The Takeaway</h4>
          <p className="text-slate-400 text-sm">
            Increasing the length (<strong className="text-white">L</strong>) has a linear effect, but it's much easier for humans to remember longer passwords (like passphrases) than purely random strings from a larger character pool (<strong className="text-white">R</strong>). A 20-character passphrase of lowercase words often has higher entropy than an 8-character random string of all symbols.
          </p>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass-card p-8 rounded-2xl border-l-4 border-l-neon-blue"
      >
        <div className="flex items-center gap-3 mb-6">
          <BrainCircuit className="text-neon-blue" size={28} />
          <h2 className="text-2xl font-bold text-white">Human Behavior in Password Selection</h2>
        </div>
        <p className="text-slate-300 leading-relaxed mb-4">
          When forced to create complex passwords (e.g., "Must contain 1 uppercase, 1 number, 1 symbol"), humans fall into predictable patterns:
        </p>
        <ul className="list-disc pl-5 space-y-2 text-slate-300 mb-6">
          <li>Capitalizing only the first letter.</li>
          <li>Adding "1" or "123" to the end.</li>
          <li>Using "!" as the required symbol, always at the very end.</li>
          <li>Using keyboard walks like "qwerty" or "asdf".</li>
        </ul>
        <div className="bg-neon-blue/10 p-4 rounded-xl border border-neon-blue/20">
          <p className="text-slate-400 text-sm">
            Attackers are aware of these patterns. Password cracking algorithms like Hashcat use rule-based dictionaries that specifically test these predictable human modifications. This is why our <strong className="text-white">Pattern Detection</strong> engine flags these behaviors.
          </p>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-card p-8 rounded-2xl border-l-4 border-l-neon-green"
      >
        <div className="flex items-center gap-3 mb-6">
          <Fingerprint className="text-neon-green" size={28} />
          <h2 className="text-2xl font-bold text-white">NIST Password Guidelines (Latest)</h2>
        </div>
        <p className="text-slate-300 leading-relaxed mb-4">
          The National Institute of Standards and Technology (NIST) updated its digital identity guidelines, overturning decades of previous advice:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <h4 className="text-neon-red font-bold mb-2 line-through opacity-70">Old Advice</h4>
            <ul className="text-sm text-slate-400 space-y-1">
              <li>- Require arbitrary complexity (mix of characters)</li>
              <li>- Force password expiration every 30-90 days</li>
              <li>- Use password hints</li>
            </ul>
          </div>
          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <h4 className="text-neon-green font-bold mb-2">New Guidelines</h4>
            <ul className="text-sm text-slate-400 space-y-1">
              <li>- Favor length over complexity (Passphrases)</li>
              <li>- Do NOT force expiration unless compromised</li>
              <li>- Check passwords against breached databases</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
