import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Bell, Shield, Monitor } from 'lucide-react';

export default function Settings() {
  const [theme, setTheme] = useState('dark');
  const [notifications, setNotifications] = useState(true);
  const [strictMode, setStrictMode] = useState(true);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">System Settings</h1>
        <p className="text-slate-400">Configure your dashboard preferences and analysis parameters.</p>
      </header>

      <div className="space-y-6">
        {/* Appearance */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 md:p-8 rounded-2xl"
        >
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Monitor size={20} className="text-neon-blue" />
            Appearance
          </h2>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => setTheme('dark')}
              className={`flex-1 p-4 rounded-xl border flex flex-col items-center gap-3 transition-all ${theme === 'dark' ? 'bg-slate-800/80 border-neon-blue text-white ring-1 ring-neon-blue shadow-[0_0_15px_rgba(59,130,246,0.15)]' : 'bg-slate-900/50 border-slate-700 text-slate-400 hover:border-slate-500'}`}
            >
              <Moon size={24} />
              <span className="font-medium">Dark Mode (Cyber)</span>
            </button>
            <button 
              onClick={() => setTheme('light')}
              disabled
              className={`flex-1 p-4 rounded-xl border flex flex-col items-center gap-3 transition-all opacity-50 cursor-not-allowed bg-slate-900/50 border-slate-700 text-slate-400`}
              title="Light mode is disabled to maintain optimal hacker aesthetic."
            >
              <Sun size={24} />
              <span className="font-medium">Light Mode</span>
              <span className="text-xs text-neon-red absolute bottom-2">Locked</span>
            </button>
          </div>
        </motion.div>

        {/* Preferences */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-6 md:p-8 rounded-2xl"
        >
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <Shield size={20} className="text-neon-purple" />
            Analysis Preferences
          </h2>
          
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-medium">Strict Password Validation</h3>
                <p className="text-sm text-slate-400 mt-1">Require higher entropy for a "Strong" rating.</p>
              </div>
              <button 
                onClick={() => setStrictMode(!strictMode)}
                className={`w-12 h-6 rounded-full transition-colors relative ${strictMode ? 'bg-neon-blue' : 'bg-slate-700'}`}
              >
                <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${strictMode ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>

            <div className="h-px w-full bg-slate-800" />

            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-medium">Security Alerts</h3>
                <p className="text-sm text-slate-400 mt-1">Show browser notifications for critical findings.</p>
              </div>
              <button 
                onClick={() => setNotifications(!notifications)}
                className={`w-12 h-6 rounded-full transition-colors relative ${notifications ? 'bg-neon-blue' : 'bg-slate-700'}`}
              >
                <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${notifications ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
