import React from 'react';
import { useOutletContext } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AlertTriangle, CircleCheck, CircleAlert, RefreshCcw, ShieldAlert, Zap } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';

interface AnalyzerContext {
  password: string;
  result: any;
  entropy: number;
}

export function AnalyzerEntropy() {
  const { password, entropy, result } = useOutletContext<AnalyzerContext>();

  // Fake chart data based on password length to show entropy growth
  const chartData = password.split('').map((char, index) => {
    const subStr = password.substring(0, index + 1);
    const charset = new Set(subStr).size;
    const partialEntropy = Math.round(subStr.length * Math.log2(charset || 1));
    return {
      name: `Char ${index + 1}`,
      entropy: partialEntropy
    };
  });

  return (
    <div className="space-y-6 mt-6">
      <div className="glass-card p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">Entropy Analysis</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
            <p className="text-sm text-slate-400 mb-1">Total Entropy</p>
            <h3 className="text-3xl font-bold text-neon-purple">{entropy} <span className="text-base text-slate-500">bits</span></h3>
          </div>
          <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
            <p className="text-sm text-slate-400 mb-1">Character Set Size</p>
            <h3 className="text-3xl font-bold text-neon-blue">{new Set(password).size} <span className="text-base text-slate-500">unique</span></h3>
          </div>
          <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
            <p className="text-sm text-slate-400 mb-1">Password Length</p>
            <h3 className="text-3xl font-bold text-white">{password.length} <span className="text-base text-slate-500">chars</span></h3>
          </div>
        </div>
        
        {password.length > 0 ? (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{ fill: '#1e293b' }}
                  contentStyle={{ backgroundColor: '#0B1120', borderColor: '#334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#8B5CF6' }}
                />
                <Bar dataKey="entropy" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={`hsl(258, 90%, ${Math.max(40, 70 - (index * 2))}%)`} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-64 flex items-center justify-center text-slate-500 border border-dashed border-slate-700 rounded-xl">
            Enter a password to view entropy growth graph
          </div>
        )}
      </div>
    </div>
  );
}

export function AnalyzerPatterns() {
  const { password, result } = useOutletContext<AnalyzerContext>();

  const patterns = result?.sequence || [];

  return (
    <div className="space-y-6 mt-6">
      <div className="glass-card p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-4">Pattern & Dictionary Detection</h2>
        
        {!password ? (
          <p className="text-slate-400">Enter a password to detect common patterns and dictionary words.</p>
        ) : patterns.length === 0 ? (
          <div className="flex items-center gap-3 text-neon-green p-4 bg-neon-green/10 border border-neon-green/20 rounded-xl">
            <CircleCheck size={24} />
            <span>No obvious patterns or dictionary words detected!</span>
          </div>
        ) : (
          <div className="space-y-4">
            {patterns.map((pattern: any, idx: number) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="flex items-start gap-4 p-4 bg-slate-800/50 rounded-xl border border-slate-700"
              >
                <div className="mt-1">
                  {pattern.pattern === 'dictionary' ? (
                    <AlertTriangle className="text-orange-500" size={20} />
                  ) : pattern.pattern === 'sequence' || pattern.pattern === 'repeat' ? (
                    <RefreshCcw className="text-neon-red" size={20} />
                  ) : (
                    <CircleAlert className="text-neon-blue" size={20} />
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-bold text-white capitalize">{pattern.pattern} Pattern</h4>
                    <span className="text-xs font-mono bg-slate-900 px-2 py-1 rounded text-slate-300">
                      chars: {pattern.token}
                    </span>
                  </div>
                  <p className="text-sm text-slate-400">
                    {pattern.pattern === 'dictionary' && `Found in ${pattern.dictionary_name} dictionary.`}
                    {pattern.pattern === 'sequence' && `Sequential characters detected.`}
                    {pattern.pattern === 'repeat' && `Repeated characters detected.`}
                    {pattern.pattern === 'spatial' && `Keyboard pattern detected.`}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function AnalyzerCrackTime() {
  const { password, result } = useOutletContext<AnalyzerContext>();

  if (!password || !result) {
    return (
      <div className="mt-6 glass-card p-6 rounded-2xl text-slate-400 text-center">
        Enter a password to view crack time estimation.
      </div>
    );
  }

  const times = result.crack_times_display;

  return (
    <div className="space-y-6 mt-6">
      <div className="glass-card p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-6">Crack Time Estimation</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
            <div className="flex items-center gap-2 mb-2 text-slate-300">
              <Zap size={18} className="text-neon-red" />
              <span className="font-medium">Online Attack (Throttled)</span>
            </div>
            <p className="text-2xl font-bold text-white">{times.online_throttling_100_per_hour}</p>
            <p className="text-xs text-slate-500 mt-1">100 guesses per hour</p>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
            <div className="flex items-center gap-2 mb-2 text-slate-300">
              <Zap size={18} className="text-orange-500" />
              <span className="font-medium">Online Attack (Unthrottled)</span>
            </div>
            <p className="text-2xl font-bold text-white">{times.online_no_throttling_10_per_second}</p>
            <p className="text-xs text-slate-500 mt-1">10 guesses per second</p>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
            <div className="flex items-center gap-2 mb-2 text-slate-300">
              <ShieldAlert size={18} className="text-neon-purple" />
              <span className="font-medium">Offline Attack (Slow Hash)</span>
            </div>
            <p className="text-2xl font-bold text-white">{times.offline_slow_hashing_1e4_per_second}</p>
            <p className="text-xs text-slate-500 mt-1">10,000 guesses per second</p>
          </div>

          <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
            <div className="flex items-center gap-2 mb-2 text-slate-300">
              <ShieldAlert size={18} className="text-neon-blue" />
              <span className="font-medium">Offline Attack (Fast Hash)</span>
            </div>
            <p className="text-2xl font-bold text-white">{times.offline_fast_hashing_1e10_per_second}</p>
            <p className="text-xs text-slate-500 mt-1">10 Billion guesses per second</p>
          </div>
        </div>

        <div className="mt-6 p-4 bg-slate-900/50 rounded-xl border border-slate-800 text-sm text-slate-400">
          <strong className="text-white block mb-1">Note on Offline Attacks:</strong>
          If an attacker steals the password database (hashed passwords), they can attempt to crack them offline on powerful hardware without rate limits. Always aim for a password that withstands "Offline Fast Hashing" for at least centuries.
        </div>
      </div>
    </div>
  );
}

export function AnalyzerSuggestions() {
  const { password, result } = useOutletContext<AnalyzerContext>();

  if (!password || !result) {
    return (
      <div className="mt-6 glass-card p-6 rounded-2xl text-slate-400 text-center">
        Enter a password to get improvement suggestions.
      </div>
    );
  }

  const feedback = result.feedback;
  const hasWarning = feedback.warning;
  const hasSuggestions = feedback.suggestions && feedback.suggestions.length > 0;

  return (
    <div className="space-y-6 mt-6">
      <div className="glass-card p-6 rounded-2xl">
        <h2 className="text-xl font-bold text-white mb-6">Actionable Suggestions</h2>

        {hasWarning && (
          <div className="mb-6 p-4 bg-neon-red/10 border border-neon-red/30 rounded-xl flex items-start gap-3">
            <AlertTriangle className="text-neon-red mt-0.5" size={20} />
            <div>
              <h3 className="text-neon-red font-bold mb-1">Critical Warning</h3>
              <p className="text-slate-300 text-sm">{feedback.warning}</p>
            </div>
          </div>
        )}

        {!hasWarning && !hasSuggestions ? (
          <div className="flex items-center gap-3 p-4 bg-neon-green/10 border border-neon-green/30 rounded-xl">
            <CircleCheck className="text-neon-green" size={24} />
            <div>
              <h3 className="text-neon-green font-bold mb-1">Excellent Password!</h3>
              <p className="text-slate-300 text-sm">No further suggestions. Your password is highly secure.</p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <h3 className="text-white font-medium mb-3">To improve your password:</h3>
            {feedback.suggestions.map((suggestion: string, idx: number) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700/50">
                <div className="mt-1 bg-neon-blue/20 p-1 rounded-full">
                  <div className="w-2 h-2 rounded-full bg-neon-blue" />
                </div>
                <p className="text-slate-300 text-sm">{suggestion}</p>
              </div>
            ))}
            
            <div className="mt-6 border-t border-slate-700/50 pt-4">
               <h4 className="text-sm font-bold text-white mb-2">General Best Practices</h4>
               <ul className="text-sm text-slate-400 space-y-2 list-disc pl-5">
                 <li>Use a mix of uppercase, lowercase, numbers, and symbols.</li>
                 <li>Avoid using personal information (names, dates, etc.).</li>
                 <li>Consider using a passphrase (e.g., "CorrectHorseBatteryStaple").</li>
                 <li>Do not reuse passwords across different services.</li>
               </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
