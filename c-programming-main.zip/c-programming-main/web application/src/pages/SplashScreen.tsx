import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function SplashScreen() {
  const navigate = useNavigate();

  return (
    <>
      <style>
        {`
          .glow {
            text-shadow:
              0 0 10px #00ffff,
              0 0 20px #00ffff,
              0 0 40px #00ffff;
          }

          .loader-bar {
            width: 250px;
            height: 6px;
            background: #111;
            border-radius: 10px;
            overflow: hidden;
            margin: auto;
          }

          .loader-bar span {
            display: block;
            width: 40%;
            height: 100%;
            background: linear-gradient(to right, cyan, purple);
            animation: load 2s linear infinite;
          }

          @keyframes load {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(300%); }
          }

          .bg-circle {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.4;
            animation: cyber-pulse 4s infinite alternate;
          }

          .bg-circle-1 {
            width: 300px;
            height: 300px;
            background: cyan;
            top: 10%;
            left: 20%;
          }

          .bg-circle-2 {
            width: 250px;
            height: 250px;
            background: purple;
            bottom: 10%;
            right: 20%;
          }

          @keyframes cyber-pulse {
            from { transform: scale(1); }
            to { transform: scale(1.2); }
          }
        `}
      </style>

      <div className="bg-black min-h-screen relative overflow-hidden flex flex-col items-center justify-center text-center font-sans">
        {/* Background Glow */}
        <div className="bg-circle bg-circle-1"></div>
        <div className="bg-circle bg-circle-2"></div>

        {/* Main Screen */}
        <div className="relative z-10 flex flex-col items-center">
          {/* Logo */}
          <div className="w-32 h-32 rounded-full bg-gradient-to-r from-cyan-400 to-purple-600 flex items-center justify-center shadow-2xl mb-8">
            <h1 className="text-white text-5xl font-bold">CT</h1>
          </div>

          {/* App Name */}
          <h1 className="text-5xl sm:text-7xl font-extrabold tracking-widest text-cyan-400 glow">
            CYBER THRUST
          </h1>

          {/* Subtitle */}
          <p className="text-gray-300 mt-5 text-lg sm:text-xl tracking-wide">
            Future Powered Security Platform
          </p>

          {/* Loader */}
          <div className="loader-bar mt-10">
            <span></span>
          </div>

          {/* Loading Text */}
          <p className="text-cyan-300 mt-4 tracking-widest animate-pulse text-sm sm:text-base">
            INITIALIZING SYSTEM...
          </p>

          {/* Button */}
          <button 
            onClick={() => navigate('/home')}
            className="mt-10 px-8 py-3 border border-cyan-400 rounded-full text-cyan-300 hover:bg-cyan-400 hover:text-black transition duration-300 font-medium tracking-wide"
          >
            ENTER APP
          </button>
        </div>
      </div>
    </>
  );
}
