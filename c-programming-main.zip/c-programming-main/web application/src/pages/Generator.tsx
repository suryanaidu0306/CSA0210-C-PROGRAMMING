import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Copy, RefreshCw, CircleCheck, ShieldCheck, KeyRound } from 'lucide-react';

const CHAR_SETS = {
  uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  lowercase: 'abcdefghijklmnopqrstuvwxyz',
  numbers: '0123456789',
  symbols: '!@#$%^&*()_+~`|}{[]:;?><,./-='
};

export default function Generator() {
  const [password, setPassword] = useState('');
  const [length, setLength] = useState(16);
  const [options, setOptions] = useState({
    uppercase: true,
    lowercase: true,
    numbers: true,
    symbols: true
  });
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    let charset = '';
    if (options.uppercase) charset += CHAR_SETS.uppercase;
    if (options.lowercase) charset += CHAR_SETS.lowercase;
    if (options.numbers) charset += CHAR_SETS.numbers;
    if (options.symbols) charset += CHAR_SETS.symbols;

    if (charset === '') {
      setPassword('');
      return;
    }

    let newPassword = '';
    // Ensure at least one of each selected type if possible
    if (options.uppercase) newPassword += CHAR_SETS.uppercase[Math.floor(Math.random() * CHAR_SETS.uppercase.length)];
    if (options.lowercase) newPassword += CHAR_SETS.lowercase[Math.floor(Math.random() * CHAR_SETS.lowercase.length)];
    if (options.numbers) newPassword += CHAR_SETS.numbers[Math.floor(Math.random() * CHAR_SETS.numbers.length)];
    if (options.symbols) newPassword += CHAR_SETS.symbols[Math.floor(Math.random() * CHAR_SETS.symbols.length)];

    // Fill the rest
    for (let i = newPassword.length; i < length; i++) {
      newPassword += charset[Math.floor(Math.random() * charset.length)];
    }

    // Shuffle the result
    setPassword(newPassword.split('').sort(() => 0.5 - Math.random()).join(''));
    setCopied(false);
  };

  useEffect(() => {
    generatePassword();
  }, [length, options]);

  const copyToClipboard = () => {
    if (!password) return;
    navigator.clipboard.writeText(password);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggle = (key: keyof typeof options) => {
    setOptions(prev => {
      const next = { ...prev, [key]: !prev[key] };
      // Prevent disabling all options
      if (!Object.values(next).some(v => v)) {
        return prev;
      }
      return next;
    });
  };

  const getStrength = () => {
    if (length < 8) return 'bg-neon-red';
    if (length < 12) return 'bg-orange-500';
    if (length < 16) return 'bg-neon-blue';
    return 'bg-neon-green';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Cryptographic Generator</h1>
        <p className="text-slate-400">Create high-entropy passwords that resist advanced cracking techniques.</p>
      </header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-8 rounded-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-neon-blue to-neon-purple opacity-50" />
        
        {/* Output Section */}
        <div className="mb-8">
          <label className="block text-sm font-medium text-slate-400 mb-2">Generated Password</label>
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-neon-blue to-neon-purple rounded-xl blur opacity-30 group-hover:opacity-60 transition duration-500" />
            <div className="relative bg-slate-900 flex items-center justify-between rounded-xl border border-slate-700/50 p-2">
              <input
                type="text"
                readOnly
                value={password}
                className="w-full bg-transparent text-white text-2xl md:text-3xl font-mono tracking-wider px-4 focus:outline-none"
              />
              <div className="flex gap-2">
                <button
                  onClick={copyToClipboard}
                  className="p-3 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2"
                  title="Copy to clipboard"
                >
                  {copied ? <CircleCheck className="text-neon-green" /> : <Copy />}
                  <span className="hidden sm:inline font-medium">{copied ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={generatePassword}
                  className="p-3 bg-neon-blue text-white rounded-lg hover:bg-blue-600 transition-colors flex items-center gap-2"
                  title="Generate new password"
                >
                  <RefreshCw className="hover:rotate-180 transition-transform duration-500" />
                  <span className="hidden sm:inline font-medium">Generate</span>
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex gap-1 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
             <div className={`h-full transition-all duration-300 ${getStrength()}`} style={{ width: `${(length / 64) * 100}%` }} />
          </div>
        </div>

        {/* Controls Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Slider */}
          <div className="space-y-4">
            <div className="flex justify-between text-white font-medium">
              <span>Length</span>
              <span className="text-neon-blue text-xl">{length}</span>
            </div>
            <input
              type="range"
              min="4"
              max="64"
              value={length}
              onChange={(e) => setLength(Number(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-neon-blue"
            />
            <div className="flex justify-between text-xs text-slate-500 font-mono">
              <span>4</span>
              <span>32</span>
              <span>64</span>
            </div>
            
            <div className="mt-8 p-4 bg-slate-800/50 border border-slate-700/50 rounded-xl flex items-start gap-3">
              <ShieldCheck className="text-neon-green mt-1 flex-shrink-0" />
              <p className="text-sm text-slate-400 leading-relaxed">
                A length of <strong>16+ characters</strong> with mixed character types is recommended to withstand modern offline dictionary and brute-force attacks.
              </p>
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-4">
            <span className="block text-white font-medium mb-4">Character Sets</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { id: 'uppercase', label: 'A-Z', name: 'Uppercase' },
                { id: 'lowercase', label: 'a-z', name: 'Lowercase' },
                { id: 'numbers', label: '0-9', name: 'Numbers' },
                { id: 'symbols', label: '!@#$', name: 'Symbols' }
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => handleToggle(opt.id as keyof typeof options)}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                    options[opt.id as keyof typeof options]
                      ? 'bg-neon-blue/10 border-neon-blue text-white shadow-[0_0_15px_rgba(59,130,246,0.1)]'
                      : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:border-slate-600'
                  }`}
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium">{opt.name}</span>
                    <span className="text-xs opacity-70 font-mono mt-1">{opt.label}</span>
                  </div>
                  <div className={`w-5 h-5 rounded border flex items-center justify-center ${
                    options[opt.id as keyof typeof options] ? 'bg-neon-blue border-neon-blue' : 'border-slate-500'
                  }`}>
                    {options[opt.id as keyof typeof options] && <CircleCheck size={14} className="text-white" />}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
