import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Eye, EyeOff, Shield, ShieldAlert, Clock, Activity, Fingerprint, RefreshCcw, ShieldCheck } from 'lucide-react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import zxcvbn from 'zxcvbn';

export default function Analyzer() {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [result, setResult] = useState<any>(null);
  const location = useLocation();

  useEffect(() => {
    if (password) {
      setResult(zxcvbn(password));
    } else {
      setResult(null);
    }
  }, [password]);

  const getStrengthColor = (score: number) => {
    switch (score) {
      case 0: return 'bg-slate-700';
      case 1: return 'bg-neon-red';
      case 2: return 'bg-orange-500';
      case 3: return 'bg-neon-purple';
      case 4: return 'bg-neon-green';
      default: return 'bg-slate-700';
    }
  };

  const getStrengthLabel = (score: number) => {
    switch (score) {
      case 0: return 'Very Weak';
      case 1: return 'Weak';
      case 2: return 'Fair';
      case 3: return 'Strong';
      case 4: return 'Very Strong';
      default: return 'No Password';
    }
  };

  const calculateEntropy = (pw: string) => {
    if (!pw) return 0;
    // Simple rough calculation for display purposes if not using full zxcvbn entropy
    const charset = new Set(pw).size;
    return Math.round(pw.length * Math.log2(charset || 1));
  };

  const entropy = calculateEntropy(password);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <header className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Password Analyzer Engine</h1>
          <p className="text-slate-400">Real-time cryptographic analysis of your authentication string.</p>
        </div>
        <div className="flex items-center gap-2 bg-slate-800/50 px-4 py-2 rounded-lg border border-slate-700/50">
          <Shield className="text-neon-blue" size={20} />
          <span className="text-sm text-slate-300 font-medium">zxcvbn Engine Active</span>
        </div>
      </header>

      {/* Main Input Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-6 md:p-8 rounded-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-32 bg-neon-blue/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="relative mb-6">
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password to analyze..."
              className="w-full bg-slate-900/50 border-2 border-slate-700 text-white text-xl md:text-2xl px-6 py-5 rounded-xl focus:outline-none focus:border-neon-blue transition-colors font-mono tracking-wider shadow-inner"
            />
            <button
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors p-2"
            >
              {showPassword ? <EyeOff size={24} /> : <Eye size={24} />}
            </button>
          </div>

          {/* Progress Bar */}
          <div className="flex gap-2 h-3 mb-4">
            {[1, 2, 3, 4].map((level) => (
              <div 
                key={level} 
                className={`flex-1 rounded-full transition-all duration-500 ${
                  result && result.score >= level 
                    ? getStrengthColor(result.score)
                    : 'bg-slate-800'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className={`text-xl font-bold ${result ? getStrengthColor(result.score).replace('bg-', 'text-') : 'text-slate-400'}`}>
                {result ? getStrengthLabel(result.score) : 'Awaiting Input'}
              </span>
              {result && result.score === 4 && <ShieldCheck className="text-neon-green" size={24} />}
              {result && result.score < 2 && password && <ShieldAlert className="text-neon-red" size={24} />}
            </div>
            {result && (
              <span className="text-slate-400 text-sm">Score: {result.score}/4</span>
            )}
          </div>
        </div>
      </motion.div>

      {/* Sub-Navigation for detailed analysis */}
      <div className="flex overflow-x-auto gap-2 pb-2 custom-scrollbar border-b border-slate-800">
        {[
          { path: '/analyzer/entropy', label: 'Entropy', icon: Activity },
          { path: '/analyzer/patterns', label: 'Patterns', icon: Fingerprint },
          { path: '/analyzer/crack-time', label: 'Crack Time', icon: Clock },
          { path: '/analyzer/suggestions', label: 'Suggestions', icon: RefreshCcw }
        ].map((tab) => {
          const isActive = location.pathname.includes(tab.path);
          return (
            <NavLink
              key={tab.path}
              to={tab.path}
              className={`flex items-center gap-2 px-4 py-3 rounded-t-lg transition-colors whitespace-nowrap ${
                isActive 
                  ? 'bg-slate-800/80 text-neon-blue border-t-2 border-neon-blue' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <tab.icon size={18} />
              <span className="font-medium">{tab.label}</span>
            </NavLink>
          );
        })}
      </div>

      {/* Render sub-screens or default summary if at root /analyzer */}
      <AnimatePresence mode="wait">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {location.pathname === '/analyzer' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              {/* Quick Summary Cards */}
              <div className="glass-card p-6 rounded-2xl flex items-start gap-4">
                <div className="p-3 bg-neon-purple/20 rounded-xl text-neon-purple">
                  <Activity size={24} />
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Estimated Entropy</p>
                  <h3 className="text-2xl font-bold text-white">{entropy} <span className="text-sm font-normal text-slate-500">bits</span></h3>
                  <p className="text-xs text-slate-400 mt-2">Measures mathematical randomness.</p>
                </div>
              </div>

              <div className="glass-card p-6 rounded-2xl flex items-start gap-4">
                <div className="p-3 bg-neon-blue/20 rounded-xl text-neon-blue">
                  <Clock size={24} />
                </div>
                <div>
                  <p className="text-sm text-slate-400 mb-1">Offline Attack Time</p>
                  <h3 className="text-2xl font-bold text-white">
                    {result ? result.crack_times_display.offline_fast_hashing_1e10_per_second : '-'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2">Assuming 10 billion guesses/second.</p>
                </div>
              </div>
            </div>
          ) : (
             <Outlet context={{ password, result, entropy }} />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
