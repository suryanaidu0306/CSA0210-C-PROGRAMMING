import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Lock, Activity, Eye, ArrowRight, Zap, ShieldCheck } from 'lucide-react';

const features = [
  {
    icon: <Lock className="text-neon-blue" size={32} />,
    title: "Real-time Analysis",
    description: "Instant feedback on password strength with military-grade algorithms detecting weaknesses."
  },
  {
    icon: <Activity className="text-neon-purple" size={32} />,
    title: "Entropy Calculation",
    description: "Advanced mathematics measure true randomness and resistance against brute-force attacks."
  },
  {
    icon: <Eye className="text-neon-green" size={32} />,
    title: "Pattern Detection",
    description: "Identify common sequences, keyboard patterns, and dictionary words instantly."
  }
];

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      {/* Dynamic Background Elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-neon-blue/10 rounded-full blur-[128px] animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-neon-purple/10 rounded-full blur-[128px] animate-pulse-slow" style={{ animationDelay: '1.5s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[1px] bg-gradient-to-r from-transparent via-slate-800 to-transparent" />
      
      {/* Navbar Minimal */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-6 lg:px-12">
        <div className="flex items-center gap-3">
          <Shield size={32} className="text-neon-blue" />
          <span className="text-xl font-bold text-white tracking-widest">SecuriAuth</span>
        </div>
        <button 
          onClick={() => navigate('/dashboard')}
          className="text-slate-300 hover:text-white transition-colors text-sm uppercase tracking-widest font-semibold"
        >
          Access System
        </button>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 relative z-10 flex flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-800/50 border border-slate-700/50 text-slate-300 mb-8 backdrop-blur-sm">
            <Zap size={16} className="text-neon-blue" />
            <span className="text-sm font-medium">Next-Gen Authentication Security V2.0</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 tracking-tight">
            Secure Your Digital <br className="hidden md:block" />
            <span className="text-gradient">Identity Today</span>
          </h1>
          
          <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            Analyze password strength, calculate entropy, and elevate your security awareness with our advanced cyber-defense dashboard.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/analyzer')}
              className="relative group px-8 py-4 bg-neon-blue text-white rounded-lg font-bold text-lg overflow-hidden w-full sm:w-auto"
            >
              <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-neon-blue to-neon-purple opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative flex items-center justify-center gap-2">
                Analyze Password
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
            <button
              onClick={() => navigate('/dashboard')}
              className="px-8 py-4 bg-slate-800/80 hover:bg-slate-700 text-white border border-slate-700 rounded-lg font-bold text-lg backdrop-blur-sm transition-colors w-full sm:w-auto flex items-center justify-center gap-2"
            >
              <ShieldCheck size={20} />
              Security Dashboard
            </button>
          </div>
        </motion.div>

        {/* Feature Cards Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto mt-24 pb-12"
        >
          {features.map((feature, idx) => (
            <div key={idx} className="glass-card p-8 rounded-2xl text-left hover:-translate-y-2 transition-transform duration-300">
              <div className="w-14 h-14 rounded-xl bg-slate-800/50 flex items-center justify-center mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-slate-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </motion.div>
      </main>
    </div>
  );
}
