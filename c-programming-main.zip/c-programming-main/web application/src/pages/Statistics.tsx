import React from 'react';
import { motion } from 'framer-motion';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend
} from 'recharts';

const PIE_COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#EF4444', '#F59E0B'];

const dataPasswordTypes = [
  { name: 'Letters Only', value: 35 },
  { name: 'Letters + Numbers', value: 40 },
  { name: 'Complex (All Types)', value: 15 },
  { name: 'Dictionary Words', value: 10 },
];

const dataEntropyDistribution = [
  { range: '< 30 bits', count: 120 },
  { range: '30-50 bits', count: 250 },
  { range: '50-70 bits', count: 180 },
  { range: '70-90 bits', count: 90 },
  { range: '> 90 bits', count: 40 },
];

// Mock data for a heatmap (7 days x 12 weeks)
const generateHeatmapData = () => {
  const data = [];
  for (let week = 0; week < 12; week++) {
    for (let day = 0; day < 7; day++) {
      // higher chance of activity on weekdays
      const isWeekend = day === 0 || day === 6;
      const intensity = Math.floor(Math.random() * (isWeekend ? 3 : 5));
      data.push({ week, day, intensity });
    }
  }
  return data;
};

const heatmapData = generateHeatmapData();

const getHeatmapColor = (intensity: number) => {
  switch (intensity) {
    case 0: return 'bg-slate-800/50';
    case 1: return 'bg-neon-blue/20';
    case 2: return 'bg-neon-blue/50';
    case 3: return 'bg-neon-blue/80';
    case 4: return 'bg-neon-blue';
    default: return 'bg-slate-800/50';
  }
};

export default function Statistics() {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Global Security Statistics</h1>
        <p className="text-slate-400">Aggregate data analysis of password patterns and vulnerabilities.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Pie Chart: Password Composition */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-6 rounded-2xl"
        >
          <h2 className="text-xl font-bold text-white mb-6">Common Password Compositions</h2>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={dataPasswordTypes}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={110}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {dataPasswordTypes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#0B1120', borderColor: '#334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Legend verticalAlign="bottom" height={36} wrapperStyle={{ color: '#94a3b8' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Bar Chart: Entropy Distribution */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-6 rounded-2xl"
        >
          <h2 className="text-xl font-bold text-white mb-6">Entropy Distribution (Sample Size: 680)</h2>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dataEntropyDistribution} margin={{ top: 20, right: 30, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="range" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <RechartsTooltip 
                  cursor={{ fill: '#1e293b' }}
                  contentStyle={{ backgroundColor: '#0B1120', borderColor: '#334155', borderRadius: '8px' }}
                />
                <Bar dataKey="count" fill="#8B5CF6" radius={[4, 4, 0, 0]}>
                  {dataEntropyDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index > 2 ? '#10B981' : index === 0 ? '#EF4444' : '#8B5CF6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Heatmap: Analysis Frequency */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card p-6 rounded-2xl lg:col-span-2 overflow-x-auto"
        >
          <h2 className="text-xl font-bold text-white mb-6">User Analysis Activity (Last 12 Weeks)</h2>
          <div className="min-w-[600px]">
            <div className="flex gap-1 mb-2 text-xs text-slate-500 pl-8">
              {Array.from({length: 12}).map((_, i) => (
                <div key={i} className="flex-1 text-center">W{i+1}</div>
              ))}
            </div>
            <div className="flex">
              <div className="flex flex-col gap-1 pr-2 text-xs text-slate-500 justify-around py-1">
                <span>Sun</span>
                <span>Mon</span>
                <span>Tue</span>
                <span>Wed</span>
                <span>Thu</span>
                <span>Fri</span>
                <span>Sat</span>
              </div>
              <div className="flex-1 grid grid-cols-12 gap-1">
                {Array.from({length: 12}).map((_, week) => (
                  <div key={week} className="flex flex-col gap-1">
                    {Array.from({length: 7}).map((_, day) => {
                      const cellData = heatmapData.find(d => d.week === week && d.day === day);
                      return (
                        <div 
                          key={day} 
                          className={`w-full aspect-square rounded-sm ${getHeatmapColor(cellData?.intensity || 0)} transition-colors hover:ring-2 ring-white`}
                          title={`Activity Level: ${cellData?.intensity || 0}`}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 mt-4 text-xs text-slate-500">
              <span>Less</span>
              <div className="flex gap-1">
                {[0, 1, 2, 3, 4].map(level => (
                  <div key={level} className={`w-3 h-3 rounded-sm ${getHeatmapColor(level)}`} />
                ))}
              </div>
              <span>More</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
