import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { BookOpenCheck, CircleHelp, Shield, Smartphone, Key, Lock, AlertTriangle } from 'lucide-react';

export default function Awareness() {
  const location = useLocation();
  const navigate = useNavigate();

  // If we are exactly at /awareness, we show the main content.
  // Otherwise, we show the Outlet (for /awareness/quiz)
  const isRoot = location.pathname === '/awareness';

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <header className="mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Security Awareness</h1>
          <p className="text-slate-400">Educate yourself on modern threats and best practices for digital identity.</p>
        </div>
        <div className="flex bg-slate-800/50 p-1 rounded-xl border border-slate-700">
          <NavLink 
            to="/awareness" 
            end
            className={({ isActive }) => `flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${isActive ? 'bg-neon-blue text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <BookOpenCheck size={16} />
            Learn
          </NavLink>
          <NavLink 
            to="/awareness/quiz" 
            className={({ isActive }) => `flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${isActive ? 'bg-neon-purple text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <CircleHelp size={16} />
            Take Quiz
          </NavLink>
        </div>
      </header>

      <AnimatePresence mode="wait">
        {isRoot ? (
          <motion.div
            key="learn"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-8"
          >
            {/* MFA Section */}
            <section className="glass-card p-8 rounded-2xl relative overflow-hidden border-neon-blue/30">
              <div className="absolute -right-20 -top-20 w-64 h-64 bg-neon-blue/10 blur-[60px] rounded-full pointer-events-none" />
              <div className="flex flex-col md:flex-row gap-8 items-center">
                <div className="flex-1">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-blue/20 text-neon-blue text-sm font-bold mb-4">
                    <Shield size={16} />
                    Critical Practice
                  </div>
                  <h2 className="text-3xl font-bold text-white mb-4">Multi-Factor Authentication (MFA)</h2>
                  <p className="text-slate-300 leading-relaxed mb-6">
                    Passwords alone are no longer sufficient. MFA adds a layer of defense by requiring two or more pieces of evidence to authenticate your identity. Even if your password is stolen, attackers cannot access your account without the second factor.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-slate-300">
                      <Smartphone className="text-neon-blue mt-1 flex-shrink-0" size={20} />
                      <span><strong>Something you have:</strong> A smartphone app (Google Authenticator), hardware token (YubiKey), or SMS code.</span>
                    </li>
                    <li className="flex items-start gap-3 text-slate-300">
                      <Key className="text-neon-blue mt-1 flex-shrink-0" size={20} />
                      <span><strong>Something you know:</strong> Your password or PIN.</span>
                    </li>
                  </ul>
                </div>
                <div className="w-full md:w-1/3 aspect-square max-w-[250px] relative">
                  {/* Decorative MFA Graphic */}
                  <div className="absolute inset-0 bg-gradient-to-br from-neon-blue/20 to-neon-purple/20 rounded-full animate-pulse-slow" />
                  <div className="absolute inset-4 bg-slate-900 rounded-full border-4 border-slate-800 flex items-center justify-center">
                     <Smartphone size={64} className="text-neon-blue relative z-10" />
                     <Shield size={48} className="text-neon-green absolute bottom-6 right-6" />
                  </div>
                </div>
              </div>
            </section>

            {/* Grid of Tips */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="glass-card p-6 rounded-2xl hover:border-neon-purple/50 transition-colors">
                <Lock className="text-neon-purple mb-4" size={32} />
                <h3 className="text-xl font-bold text-white mb-3">Password Managers</h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  Humans are terrible at remembering long, random strings of characters. A password manager generates, stores, and autofills complex passwords for you. You only need to remember one strong master password.
                </p>
              </div>

              <div className="glass-card p-6 rounded-2xl hover:border-orange-500/50 transition-colors">
                <AlertTriangle className="text-orange-500 mb-4" size={32} />
                <h3 className="text-xl font-bold text-white mb-3">Phishing Awareness</h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  The strongest password won't protect you if you hand it directly to an attacker. Always verify the URL before entering credentials. Be skeptical of urgent emails demanding immediate login action.
                </p>
              </div>
            </div>

            {/* Call to Action for Quiz */}
            <div className="bg-gradient-to-r from-neon-blue/10 to-neon-purple/10 p-8 rounded-2xl border border-slate-700/50 text-center">
              <h3 className="text-2xl font-bold text-white mb-2">Test Your Knowledge</h3>
              <p className="text-slate-400 mb-6">Think you know the basics of cybersecurity? Take our interactive quiz to find out.</p>
              <button 
                onClick={() => navigate('/awareness/quiz')}
                className="px-6 py-3 bg-white text-slate-900 font-bold rounded-lg hover:bg-slate-200 transition-colors"
              >
                Start Quiz Now
              </button>
            </div>
          </motion.div>
        ) : (
          <Outlet />
        )}
      </AnimatePresence>
    </div>
  );
}
