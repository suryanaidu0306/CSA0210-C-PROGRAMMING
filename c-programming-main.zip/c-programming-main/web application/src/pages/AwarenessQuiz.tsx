import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CircleCheck, CircleX, Award, RefreshCw } from 'lucide-react';

const QUIZ_QUESTIONS = [
  {
    id: 1,
    question: "What is the primary benefit of Multi-Factor Authentication (MFA)?",
    options: [
      "It makes your password completely unbreakable.",
      "It requires an attacker to steal both your password and a secondary device/token.",
      "It speeds up the login process significantly.",
      "It prevents your computer from getting viruses."
    ],
    correctAnswer: 1,
    explanation: "MFA requires something you know (password) and something you have (e.g., phone), meaning a stolen password alone isn't enough for an attacker to gain access."
  },
  {
    id: 2,
    question: "Which of the following makes a password cryptographically 'strong'?",
    options: [
      "Using a word found in the dictionary backwards.",
      "Replacing letters with similar-looking numbers (e.g., E -> 3, O -> 0).",
      "High entropy (length and true randomness).",
      "Changing it every 30 days."
    ],
    correctAnswer: 2,
    explanation: "High entropy, achieved through length and unpredictable character combinations, is the mathematical measure of resistance against guessing and brute-force attacks."
  },
  {
    id: 3,
    question: "You receive an urgent email from your 'bank' asking you to click a link and verify your password. What is this called?",
    options: [
      "Brute force attack",
      "Phishing",
      "Keylogging",
      "Ransomware"
    ],
    correctAnswer: 1,
    explanation: "Phishing is a social engineering attack where the attacker masquerades as a trusted entity to trick victims into revealing sensitive information like credentials."
  },
  {
    id: 4,
    question: "Why should you NOT reuse passwords across different websites?",
    options: [
      "It violates website terms of service.",
      "If one site experiences a data breach, attackers will try that password on every other site you use.",
      "Your web browser will get confused and autofill incorrectly.",
      "It actually is safe as long as the password is strong."
    ],
    correctAnswer: 1,
    explanation: "Credential stuffing attacks use passwords leaked from one breach to attempt logins on many other popular websites. Unique passwords contain the damage."
  }
];

export default function AwarenessQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedAnswer(index);
    setIsAnswered(true);
    if (index === QUIZ_QUESTIONS[currentQuestion].correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestion < QUIZ_QUESTIONS.length - 1) {
      setCurrentQuestion(c => c + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setScore(0);
    setIsFinished(false);
  };

  if (isFinished) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-10 rounded-2xl text-center max-w-2xl mx-auto mt-8"
      >
        <Award size={64} className={`mx-auto mb-6 ${score === QUIZ_QUESTIONS.length ? 'text-neon-green' : 'text-neon-blue'}`} />
        <h2 className="text-3xl font-bold text-white mb-2">Quiz Completed!</h2>
        <p className="text-slate-400 mb-8">You scored {score} out of {QUIZ_QUESTIONS.length}.</p>
        
        <div className="flex justify-center">
          <button 
            onClick={resetQuiz}
            className="flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors border border-slate-700"
          >
            <RefreshCw size={18} />
            Retake Quiz
          </button>
        </div>
      </motion.div>
    );
  }

  const q = QUIZ_QUESTIONS[currentQuestion];

  return (
    <motion.div 
      key={currentQuestion}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="glass-card p-6 md:p-10 rounded-2xl max-w-3xl mx-auto mt-6"
    >
      <div className="flex justify-between items-center mb-8">
        <span className="text-neon-blue font-bold text-sm tracking-widest uppercase">Question {currentQuestion + 1} of {QUIZ_QUESTIONS.length}</span>
        <span className="text-slate-400 text-sm">Score: {score}</span>
      </div>

      <h3 className="text-xl md:text-2xl font-bold text-white mb-8 leading-relaxed">
        {q.question}
      </h3>

      <div className="space-y-3 mb-8">
        {q.options.map((option, idx) => {
          let buttonClass = "w-full text-left p-4 rounded-xl border transition-all duration-300 ";
          
          if (!isAnswered) {
            buttonClass += "bg-slate-800/40 border-slate-700 hover:bg-slate-800 hover:border-slate-500 text-slate-300";
          } else {
            if (idx === q.correctAnswer) {
              buttonClass += "bg-neon-green/20 border-neon-green text-white"; // Correct answer highlights green
            } else if (idx === selectedAnswer && idx !== q.correctAnswer) {
              buttonClass += "bg-neon-red/20 border-neon-red text-white"; // Wrong picked answer highlights red
            } else {
              buttonClass += "bg-slate-900/50 border-slate-800 text-slate-500 opacity-50"; // Others fade out
            }
          }

          return (
            <button
              key={idx}
              onClick={() => handleSelect(idx)}
              disabled={isAnswered}
              className={buttonClass}
            >
              <div className="flex justify-between items-center">
                <span>{option}</span>
                {isAnswered && idx === q.correctAnswer && <CircleCheck className="text-neon-green flex-shrink-0 ml-2" size={20} />}
                {isAnswered && idx === selectedAnswer && idx !== q.correctAnswer && <CircleX className="text-neon-red flex-shrink-0 ml-2" size={20} />}
              </div>
            </button>
          );
        })}
      </div>

      <AnimatePresence>
        {isAnswered && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="overflow-hidden"
          >
            <div className={`p-4 rounded-xl border mb-6 ${selectedAnswer === q.correctAnswer ? 'bg-neon-green/10 border-neon-green/30' : 'bg-slate-800/80 border-slate-700'}`}>
              <h4 className="font-bold text-white mb-1">Explanation</h4>
              <p className="text-slate-300 text-sm">{q.explanation}</p>
            </div>
            
            <div className="flex justify-end">
              <button
                onClick={handleNext}
                className="px-8 py-3 bg-neon-blue text-white font-bold rounded-lg hover:bg-blue-600 transition-colors"
              >
                {currentQuestion < QUIZ_QUESTIONS.length - 1 ? 'Next Question' : 'View Results'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
