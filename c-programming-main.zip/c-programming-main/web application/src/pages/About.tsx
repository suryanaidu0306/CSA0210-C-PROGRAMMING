import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Globe, Code, ExternalLink } from 'lucide-react';

export default function About() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <header className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">About Project</h1>
          <p className="text-slate-400">Information regarding the SecuriAuth system architecture and purpose.</p>
        </div>
        <Shield size={48} className="text-neon-blue opacity-50 hidden sm:block" />
      </header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card p-8 rounded-2xl relative overflow-hidden"
      >
        <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-neon-purple/10 blur-[80px] rounded-full pointer-events-none" />
        
        <div className="space-y-8 relative z-10">
          <section>
            <h2 className="text-xl font-bold text-white mb-3">Objective</h2>
            <p className="text-slate-300 leading-relaxed">
              The Password Strength Analyzer and Security Awareness System (SecuriAuth) was built to provide an educational, interactive, and highly visual approach to digital security. It aims to demystify cryptographic concepts like entropy and demonstrate exactly how attackers exploit human psychological patterns during authentication.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-3 flex items-center gap-2">
              <Code size={20} className="text-neon-blue" />
              Technologies Used
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { name: 'React 18', desc: 'UI Library' },
                { name: 'Vite', desc: 'Build Tool' },
                { name: 'Tailwind CSS', desc: 'Styling' },
                { name: 'Framer Motion', desc: 'Animations' },
                { name: 'Recharts', desc: 'Data Visualization' },
                { name: 'zxcvbn', desc: 'Analysis Engine' },
                { name: 'Lucide', desc: 'Iconography' },
                { name: 'TypeScript', desc: 'Type Safety' }
              ].map((tech) => (
                <div key={tech.name} className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 flex flex-col items-center justify-center text-center">
                  <span className="font-bold text-white text-sm">{tech.name}</span>
                  <span className="text-xs text-slate-400 mt-1">{tech.desc}</span>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-3">Architecture</h2>
            <p className="text-slate-300 leading-relaxed mb-4">
              This application utilizes a <strong>Frontend-Only Architecture</strong>. All cryptographic calculations, entropy estimations, and dictionary checks are performed locally in your browser. No passwords are ever transmitted to an external server, ensuring complete privacy during analysis.
            </p>
            <div className="p-4 bg-neon-green/10 border border-neon-green/30 rounded-xl text-sm text-neon-green flex items-center gap-2">
              <Shield size={16} />
              <span>Zero-knowledge client-side processing verified.</span>
            </div>
          </section>

          <section className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="text-sm text-slate-400">
              Version 2.0.0 &bull; MIT License
            </div>
            <div className="flex gap-4">
              <button className="flex items-center gap-2 text-sm text-slate-300 hover:text-white transition-colors">
                <Globe size={18} />
                Source Code
              </button>
              <button className="flex items-center gap-2 text-sm text-neon-blue hover:text-blue-400 transition-colors">
                <ExternalLink size={18} />
                Documentation
              </button>
            </div>
          </section>
        </div>
      </motion.div>
    </div>
  );
}
